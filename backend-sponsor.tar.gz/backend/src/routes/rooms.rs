use axum::{
    extract::{Path, State},
    routing::{get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use sqlx::Row;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;
use crate::room_sessions;
use crate::ws::WsEvent;

const MAX_PLAYERS: i32 = 5;

#[derive(Serialize)]
pub struct RoomMemberRow {
    pub user_id: String,
    pub nickname: String,
    pub role: String,
    pub is_sponsor: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub joined_at: Option<String>,
}

#[derive(Serialize)]
pub struct RoomRow {
    pub id: String,
    pub owner_user_id: String,
    pub status: String,
    pub max_players: i32,
    pub member_count: i32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub created_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub members: Option<Vec<RoomMemberRow>>,
}

#[derive(Serialize)]
struct RoomsListResponse {
    rooms: Vec<RoomRow>,
}

#[derive(Serialize)]
struct RoomResponse {
    room: RoomRow,
}

#[derive(Deserialize)]
pub struct CreateRoomBody {
    #[serde(default)]
    pub max_players: Option<i32>,
}

#[derive(Deserialize)]
pub struct JoinLeaveBody {
    pub room_id: Uuid,
    /// If set and caller is owner — kick this member instead of leaving.
    #[serde(default)]
    pub user_id: Option<Uuid>,
}

#[derive(Deserialize)]
pub struct InviteBody {
    pub room_id: Uuid,
    pub nickname: String,
}

#[derive(Serialize)]
struct SuccessResponse {
    success: bool,
}

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/rooms", get(list_rooms).post(create_room))
        .route("/rooms/friends", get(list_friends_rooms))
        .route("/rooms/join", post(join_room))
        .route("/rooms/leave", post(leave_room))
        .route("/rooms/invite", post(invite_to_room))
        .route("/rooms/{id}", get(get_room).delete(close_room))
}

async fn refresh_room_status(
    pool: &sqlx::PgPool,
    room_id: Uuid,
) -> Result<(), ApiError> {
    let row = sqlx::query(
        r#"
        SELECT r.status, r.max_players,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = r.id) AS member_count
        FROM rooms r
        WHERE r.id = $1
        "#,
    )
    .bind(room_id)
    .fetch_optional(pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::NotFound)?;

    let status: String = row.get("status");
    if status == "closed" {
        return Ok(());
    }

    let max_players: i32 = row.get("max_players");
    let member_count: i32 = row.get("member_count");
    let next = if member_count >= max_players {
        "full"
    } else {
        "open"
    };

    if next != status {
        sqlx::query("UPDATE rooms SET status = $2 WHERE id = $1 AND status != 'closed'")
            .bind(room_id)
            .bind(next)
            .execute(pool)
            .await
            .map_err(|e| ApiError::Internal(e.to_string()))?;
    }

    Ok(())
}

fn map_room_row(row: &sqlx::postgres::PgRow, members: Option<Vec<RoomMemberRow>>) -> RoomRow {
    RoomRow {
        id: row.get::<Uuid, _>("id").to_string(),
        owner_user_id: row.get::<Uuid, _>("owner_user_id").to_string(),
        status: row.get("status"),
        max_players: row.get("max_players"),
        member_count: row.get("member_count"),
        created_at: row
            .get::<Option<chrono::DateTime<chrono::Utc>>, _>("created_at")
            .map(|dt| dt.to_rfc3339()),
        members,
    }
}

async fn load_members(
    pool: &sqlx::PgPool,
    room_id: Uuid,
) -> Result<Vec<RoomMemberRow>, ApiError> {
    let rows = sqlx::query(
        r#"
        SELECT m.user_id, u.nickname, m.role, u.is_sponsor, m.joined_at
        FROM room_members m
        JOIN users u ON u.id = m.user_id
        WHERE m.room_id = $1
        ORDER BY
            CASE WHEN m.role = 'owner' THEN 0 ELSE 1 END,
            m.joined_at ASC
        "#,
    )
    .bind(room_id)
    .fetch_all(pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(rows
        .into_iter()
        .map(|row| RoomMemberRow {
            user_id: row.get::<Uuid, _>("user_id").to_string(),
            nickname: row.get("nickname"),
            role: row.get("role"),
            is_sponsor: row.get("is_sponsor"),
            joined_at: row
                .get::<Option<chrono::DateTime<chrono::Utc>>, _>("joined_at")
                .map(|dt| dt.to_rfc3339()),
        })
        .collect())
}

async fn fetch_room(
    pool: &sqlx::PgPool,
    room_id: Uuid,
    with_members: bool,
) -> Result<RoomRow, ApiError> {
    let row = sqlx::query(
        r#"
        SELECT r.id, r.owner_user_id, r.status, r.max_players, r.created_at,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = r.id) AS member_count
        FROM rooms r
        WHERE r.id = $1
        "#,
    )
    .bind(room_id)
    .fetch_optional(pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::NotFound)?;

    let members = if with_members {
        Some(load_members(pool, room_id).await?)
    } else {
        None
    };

    Ok(map_room_row(&row, members))
}

async fn room_member_ids(pool: &sqlx::PgPool, room_id: Uuid) -> Result<Vec<Uuid>, ApiError> {
    let rows = sqlx::query("SELECT user_id FROM room_members WHERE room_id = $1")
        .bind(room_id)
        .fetch_all(pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(rows
        .into_iter()
        .map(|row| row.get::<Uuid, _>("user_id"))
        .collect())
}

async fn emit_room_updated(state: &AppState, room_id: Uuid) -> Result<(), ApiError> {
    let room = fetch_room(&state.pool, room_id, false).await?;
    let members = room_member_ids(&state.pool, room_id).await?;
    state
        .ws
        .send_to_users(
            members,
            WsEvent::RoomUpdated {
                room_id: room.id.clone(),
                status: room.status,
                member_count: room.member_count,
            },
        )
        .await;
    Ok(())
}

async fn create_room(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<CreateRoomBody>,
) -> Result<Json<RoomResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    crate::rate_limit::check(&state, crate::rate_limit::ROOM_CREATE, &user_id.to_string()).await?;
    let max_players = body.max_players.unwrap_or(MAX_PLAYERS);
    if !(1..=MAX_PLAYERS).contains(&max_players) {
        return Err(ApiError::bad_request(format!(
            "max_players must be between 1 and {MAX_PLAYERS}"
        )));
    }

    let mut tx = state
        .pool
        .begin()
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    let room_id: Uuid = sqlx::query_scalar(
        r#"
        INSERT INTO rooms (owner_user_id, status, max_players)
        VALUES ($1, 'open', $2)
        RETURNING id
        "#,
    )
    .bind(user_id)
    .bind(max_players)
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    sqlx::query(
        r#"
        INSERT INTO room_members (room_id, user_id, role)
        VALUES ($1, $2, 'owner')
        "#,
    )
    .bind(room_id)
    .bind(user_id)
    .execute(&mut *tx)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    tx.commit()
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    let room = fetch_room(&state.pool, room_id, true).await?;
    let _ = room_sessions::ensure_waiting_session(&state, room_id, user_id).await;
    crate::audit::room_create(&state, user_id, room_id).await;
    state
        .ws
        .send_to_user(
            user_id,
            WsEvent::RoomCreated {
                room_id: room_id.to_string(),
                owner_user_id: user_id.to_string(),
            },
        )
        .await;
    Ok(Json(RoomResponse { room }))
}

async fn list_rooms(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<RoomsListResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let rows = sqlx::query(
        r#"
        SELECT r.id, r.owner_user_id, r.status, r.max_players, r.created_at,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = r.id) AS member_count
        FROM rooms r
        JOIN room_members rm ON rm.room_id = r.id AND rm.user_id = $1
        WHERE r.status != 'closed'
        ORDER BY r.created_at DESC
        "#,
    )
    .bind(user_id)
    .fetch_all(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let mut rooms = Vec::with_capacity(rows.len());
    for row in rows {
        let room_id: Uuid = row.get("id");
        let members = load_members(&state.pool, room_id).await?;
        rooms.push(map_room_row(&row, Some(members)));
    }

    Ok(Json(RoomsListResponse { rooms }))
}

/// Open rooms owned by friends that the caller has not joined yet.
async fn list_friends_rooms(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<RoomsListResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let rows = sqlx::query(
        r#"
        SELECT r.id, r.owner_user_id, r.status, r.max_players, r.created_at,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = r.id) AS member_count
        FROM rooms r
        INNER JOIN friends f
            ON f.user_id = $1 AND f.friend_user_id = r.owner_user_id
        WHERE r.status IN ('open', 'full')
          AND NOT EXISTS (
              SELECT 1 FROM room_members rm
              WHERE rm.room_id = r.id AND rm.user_id = $1
          )
        ORDER BY r.created_at DESC
        "#,
    )
    .bind(user_id)
    .fetch_all(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let mut rooms = Vec::with_capacity(rows.len());
    for row in rows {
        let room_id: Uuid = row.get("id");
        let members = load_members(&state.pool, room_id).await?;
        rooms.push(map_room_row(&row, Some(members)));
    }

    Ok(Json(RoomsListResponse { rooms }))
}

async fn get_room(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Path(room_id): Path<Uuid>,
) -> Result<Json<RoomResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let is_member = sqlx::query_scalar::<_, i64>(
        "SELECT COUNT(*) FROM room_members WHERE room_id = $1 AND user_id = $2",
    )
    .bind(room_id)
    .bind(user_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if is_member == 0 {
        // Allow peeking open rooms by id (join flow) — still require auth.
        let status: Option<String> =
            sqlx::query_scalar("SELECT status FROM rooms WHERE id = $1")
                .bind(room_id)
                .fetch_optional(&state.pool)
                .await
                .map_err(|e| ApiError::Internal(e.to_string()))?;
        match status.as_deref() {
            Some("open") | Some("full") => {}
            Some(_) => return Err(ApiError::NotFound),
            None => return Err(ApiError::NotFound),
        }
    }

    let room = fetch_room(&state.pool, room_id, true).await?;
    Ok(Json(RoomResponse { room }))
}

async fn join_room(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<JoinLeaveBody>,
) -> Result<Json<RoomResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let room_id = body.room_id;

    let row = sqlx::query(
        r#"
        SELECT status, max_players,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = rooms.id) AS member_count
        FROM rooms
        WHERE id = $1
        "#,
    )
    .bind(room_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::NotFound)?;

    let status: String = row.get("status");
    let max_players: i32 = row.get("max_players");
    let member_count: i32 = row.get("member_count");

    if status == "closed" {
        return Err(ApiError::Conflict("room is closed".into()));
    }
    if status == "full" || member_count >= max_players {
        return Err(ApiError::Conflict("room is full".into()));
    }

    let already = sqlx::query_scalar::<_, i64>(
        "SELECT COUNT(*) FROM room_members WHERE room_id = $1 AND user_id = $2",
    )
    .bind(room_id)
    .bind(user_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if already > 0 {
        return Err(ApiError::Conflict("already a member of this room".into()));
    }

    let inserted = sqlx::query(
        r#"
        INSERT INTO room_members (room_id, user_id, role)
        SELECT $1, $2, 'member'
        WHERE (SELECT COUNT(*) FROM room_members WHERE room_id = $1) < $3
          AND (SELECT status FROM rooms WHERE id = $1) IN ('open', 'full')
        "#,
    )
    .bind(room_id)
    .bind(user_id)
    .bind(max_players)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if inserted.rows_affected() == 0 {
        return Err(ApiError::Conflict("room is full".into()));
    }

    refresh_room_status(&state.pool, room_id).await?;
    let nickname: String = sqlx::query_scalar("SELECT nickname FROM users WHERE id = $1")
        .bind(user_id)
        .fetch_one(&state.pool)
        .await
        .unwrap_or_else(|_| "unknown".into());
    let members = room_member_ids(&state.pool, room_id).await?;
    state
        .ws
        .send_to_users(
            members,
            WsEvent::RoomMemberJoined {
                room_id: room_id.to_string(),
                user_id: user_id.to_string(),
                nickname,
            },
        )
        .await;
    let _ = emit_room_updated(&state, room_id).await;

    let room = fetch_room(&state.pool, room_id, true).await?;
    Ok(Json(RoomResponse { room }))
}

async fn leave_room(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<JoinLeaveBody>,
) -> Result<Json<SuccessResponse>, ApiError> {
    let caller_id = extract_user_id(&state, &headers).await?;
    let room_id = body.room_id;

    let room = sqlx::query(
        "SELECT owner_user_id, status FROM rooms WHERE id = $1",
    )
    .bind(room_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::NotFound)?;

    let owner_user_id: Uuid = room.get("owner_user_id");
    let status: String = room.get("status");
    if status == "closed" {
        return Err(ApiError::Conflict("room is closed".into()));
    }

    // Kick: owner removes another member.
    if let Some(target_id) = body.user_id {
        if target_id == caller_id {
            // fall through to self-leave below
        } else {
            if caller_id != owner_user_id {
                return Err(ApiError::Unauthorized);
            }
            if target_id == owner_user_id {
                return Err(ApiError::bad_request("cannot kick the room owner"));
            }

            let result = sqlx::query(
                "DELETE FROM room_members WHERE room_id = $1 AND user_id = $2 AND role = 'member'",
            )
            .bind(room_id)
            .bind(target_id)
            .execute(&state.pool)
            .await
            .map_err(|e| ApiError::Internal(e.to_string()))?;

            if result.rows_affected() == 0 {
                return Err(ApiError::NotFound);
            }

            let members = room_member_ids(&state.pool, room_id).await?;
            let mut notify = members;
            notify.push(target_id);
            state
                .ws
                .send_to_users(
                    notify,
                    WsEvent::RoomMemberLeft {
                        room_id: room_id.to_string(),
                        user_id: target_id.to_string(),
                    },
                )
                .await;
            refresh_room_status(&state.pool, room_id).await?;
            let _ = emit_room_updated(&state, room_id).await;
            let _ = room_sessions::close_if_room_empty_or_closed(&state, room_id).await;
            return Ok(Json(SuccessResponse { success: true }));
        }
    }

    // Self-leave.
    if caller_id == owner_user_id {
        return Err(ApiError::bad_request(
            "owner cannot leave; close the room instead",
        ));
    }

    let result = sqlx::query(
        "DELETE FROM room_members WHERE room_id = $1 AND user_id = $2",
    )
    .bind(room_id)
    .bind(caller_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if result.rows_affected() == 0 {
        return Err(ApiError::NotFound);
    }

    let members = room_member_ids(&state.pool, room_id).await?;
    let mut notify = members;
    notify.push(caller_id);
    state
        .ws
        .send_to_users(
            notify,
            WsEvent::RoomMemberLeft {
                room_id: room_id.to_string(),
                user_id: caller_id.to_string(),
            },
        )
        .await;
    refresh_room_status(&state.pool, room_id).await?;
    let _ = emit_room_updated(&state, room_id).await;
    let _ = room_sessions::close_if_room_empty_or_closed(&state, room_id).await;
    Ok(Json(SuccessResponse { success: true }))
}

async fn invite_to_room(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<InviteBody>,
) -> Result<Json<RoomResponse>, ApiError> {
    let caller_id = extract_user_id(&state, &headers).await?;
    crate::rate_limit::check(&state, crate::rate_limit::ROOM_INVITE, &caller_id.to_string()).await?;
    let room_id = body.room_id;
    let nick = body.nickname.trim();
    if nick.len() < 3 {
        return Err(ApiError::bad_request("nickname too short"));
    }

    let membership = sqlx::query(
        "SELECT role FROM room_members WHERE room_id = $1 AND user_id = $2",
    )
    .bind(room_id)
    .bind(caller_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::Unauthorized)?;

    let role: String = membership.get("role");
    if role != "owner" {
        return Err(ApiError::Unauthorized);
    }

    let invitee = sqlx::query("SELECT id FROM users WHERE lower(nickname) = lower($1)")
        .bind(nick)
        .fetch_optional(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?
        .ok_or(ApiError::NotFound)?;

    let invitee_id: Uuid = invitee.get("id");
    if invitee_id == caller_id {
        return Err(ApiError::bad_request("cannot invite yourself"));
    }

    let are_friends = sqlx::query_scalar::<_, i64>(
        "SELECT COUNT(*) FROM friends WHERE user_id = $1 AND friend_user_id = $2",
    )
    .bind(caller_id)
    .bind(invitee_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if are_friends == 0 {
        return Err(ApiError::bad_request("can only invite friends"));
    }

    let row = sqlx::query(
        r#"
        SELECT status, max_players,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = rooms.id) AS member_count
        FROM rooms
        WHERE id = $1
        "#,
    )
    .bind(room_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::NotFound)?;

    let status: String = row.get("status");
    let max_players: i32 = row.get("max_players");
    let member_count: i32 = row.get("member_count");

    if status == "closed" {
        return Err(ApiError::Conflict("room is closed".into()));
    }
    if member_count >= max_players {
        return Err(ApiError::Conflict("room is full".into()));
    }

    let already = sqlx::query_scalar::<_, i64>(
        "SELECT COUNT(*) FROM room_members WHERE room_id = $1 AND user_id = $2",
    )
    .bind(room_id)
    .bind(invitee_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if already > 0 {
        return Err(ApiError::Conflict("user is already a member".into()));
    }

    let inserted = sqlx::query(
        r#"
        INSERT INTO room_members (room_id, user_id, role)
        SELECT $1, $2, 'member'
        WHERE (SELECT COUNT(*) FROM room_members WHERE room_id = $1) < $3
          AND (SELECT status FROM rooms WHERE id = $1) != 'closed'
        "#,
    )
    .bind(room_id)
    .bind(invitee_id)
    .bind(max_players)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if inserted.rows_affected() == 0 {
        return Err(ApiError::Conflict("room is full".into()));
    }

    let from_nickname: String = sqlx::query_scalar("SELECT nickname FROM users WHERE id = $1")
        .bind(caller_id)
        .fetch_one(&state.pool)
        .await
        .unwrap_or_else(|_| "unknown".into());
    let invitee_nickname: String =
        sqlx::query_scalar("SELECT nickname FROM users WHERE id = $1")
            .bind(invitee_id)
            .fetch_one(&state.pool)
            .await
            .unwrap_or_else(|_| "unknown".into());

    let _ = crate::notifications::create_notification(
        &state,
        invitee_id,
        crate::notifications::TYPE_ROOM_INVITE,
        crate::notifications::room_invite_payload(room_id, caller_id, &from_nickname),
    )
    .await;

    state
        .ws
        .send_to_user(
            invitee_id,
            WsEvent::RoomInvite {
                room_id: room_id.to_string(),
                from_user_id: caller_id.to_string(),
                from_nickname,
                to_user_id: invitee_id.to_string(),
            },
        )
        .await;

    refresh_room_status(&state.pool, room_id).await?;
    let members = room_member_ids(&state.pool, room_id).await?;
    state
        .ws
        .send_to_users(
            members,
            WsEvent::RoomMemberJoined {
                room_id: room_id.to_string(),
                user_id: invitee_id.to_string(),
                nickname: invitee_nickname,
            },
        )
        .await;
    let _ = emit_room_updated(&state, room_id).await;

    let room = fetch_room(&state.pool, room_id, true).await?;
    Ok(Json(RoomResponse { room }))
}

async fn close_room(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Path(room_id): Path<Uuid>,
) -> Result<Json<SuccessResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let owner: Option<Uuid> =
        sqlx::query_scalar("SELECT owner_user_id FROM rooms WHERE id = $1")
            .bind(room_id)
            .fetch_optional(&state.pool)
            .await
            .map_err(|e| ApiError::Internal(e.to_string()))?;

    let owner_id = owner.ok_or(ApiError::NotFound)?;
    if owner_id != user_id {
        return Err(ApiError::Unauthorized);
    }

    let result = sqlx::query(
        "UPDATE rooms SET status = 'closed' WHERE id = $1 AND status != 'closed'",
    )
    .bind(room_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if result.rows_affected() == 0 {
        return Err(ApiError::Conflict("room is already closed".into()));
    }

    let members = room_member_ids(&state.pool, room_id).await?;
    state
        .ws
        .send_to_users(
            members,
            WsEvent::RoomClosed {
                room_id: room_id.to_string(),
            },
        )
        .await;

    let _ = room_sessions::close_active_sessions(&state, room_id).await;
    crate::audit::room_close(&state, user_id, room_id).await;

    Ok(Json(SuccessResponse { success: true }))
}
