mod common;

use axum::http::StatusCode;
use serde_json::json;

use common::TestCtx;

#[tokio::test]
async fn rooms_create_join_leave_close() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let owner = ctx.register_user("rown").await;
    let guest = ctx.register_user("rgue").await;

    let (status, created) = ctx
        .request(
            "POST",
            "/rooms",
            Some(&owner.access_token),
            Some(json!({ "max_players": 5 })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{created}");
    let room_id = created["room"]["id"].as_str().unwrap().to_string();
    assert_eq!(created["room"]["status"], "open");
    assert_eq!(created["room"]["member_count"], 1);

    let (status, joined) = ctx
        .request(
            "POST",
            "/rooms/join",
            Some(&guest.access_token),
            Some(json!({ "room_id": room_id })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{joined}");

    let (status, detail) = ctx
        .request(
            "GET",
            &format!("/rooms/{room_id}"),
            Some(&owner.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(detail["room"]["member_count"], 2);

    let (status, again) = ctx
        .request(
            "POST",
            "/rooms/join",
            Some(&guest.access_token),
            Some(json!({ "room_id": room_id })),
        )
        .await;
    assert!(
        status == StatusCode::CONFLICT || status == StatusCode::BAD_REQUEST,
        "double join: {status} {again}"
    );

    let (status, left) = ctx
        .request(
            "POST",
            "/rooms/leave",
            Some(&guest.access_token),
            Some(json!({ "room_id": room_id })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{left}");

    let (status, closed) = ctx
        .request(
            "DELETE",
            &format!("/rooms/{room_id}"),
            Some(&owner.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{closed}");

    let (status, after) = ctx
        .request(
            "GET",
            &format!("/rooms/{room_id}"),
            Some(&owner.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(after["room"]["status"], "closed");
}

#[tokio::test]
async fn rooms_only_owner_can_close() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let owner = ctx.register_user("rown2").await;
    let guest = ctx.register_user("rgue2").await;

    let (_, created) = ctx
        .request(
            "POST",
            "/rooms",
            Some(&owner.access_token),
            Some(json!({})),
        )
        .await;
    let room_id = created["room"]["id"].as_str().unwrap().to_string();

    ctx.request(
        "POST",
        "/rooms/join",
        Some(&guest.access_token),
        Some(json!({ "room_id": room_id })),
    )
    .await;

    let (status, body) = ctx
        .request(
            "DELETE",
            &format!("/rooms/{room_id}"),
            Some(&guest.access_token),
            None,
        )
        .await;
    assert!(
        status == StatusCode::UNAUTHORIZED
            || status == StatusCode::BAD_REQUEST
            || status == StatusCode::CONFLICT
            || status == StatusCode::NOT_FOUND,
        "guest close: {status} {body}"
    );
}

#[tokio::test]
async fn rooms_invite_friend() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let owner = ctx.register_user("rinv").await;
    let friend = ctx.register_user("rfrn").await;

    ctx.request(
        "POST",
        "/friends/requests",
        Some(&owner.access_token),
        Some(json!({ "to_nickname": friend.nickname })),
    )
    .await;
    let (_, incoming) = ctx
        .request(
            "GET",
            "/friends/requests",
            Some(&friend.access_token),
            None,
        )
        .await;
    let request_id = incoming["incoming_requests"][0]["request_id"]
        .as_str()
        .unwrap();
    ctx.request(
        "POST",
        &format!("/friends/requests/{request_id}/accept"),
        Some(&friend.access_token),
        None,
    )
    .await;

    let (_, created) = ctx
        .request(
            "POST",
            "/rooms",
            Some(&owner.access_token),
            Some(json!({})),
        )
        .await;
    let room_id = created["room"]["id"].as_str().unwrap().to_string();

    let (status, invited) = ctx
        .request(
            "POST",
            "/rooms/invite",
            Some(&owner.access_token),
            Some(json!({
                "room_id": room_id,
                "nickname": friend.nickname,
            })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{invited}");

    let (status, notifications) = ctx
        .request("GET", "/notifications", Some(&friend.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    let list = notifications["notifications"].as_array().unwrap();
    assert!(list.iter().any(|n| n["type"] == "room_invite"));
}
