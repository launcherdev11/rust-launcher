#![allow(dead_code)]

use axum::body::Body;
use axum::http::{Request, StatusCode};
use axum::Router;
use http_body_util::BodyExt;
use mc16launcher_api::config::Config;
use mc16launcher_api::db::AppState;
use mc16launcher_api::{build_app, build_state};
use serde_json::{json, Value};
use tower::ServiceExt;
use uuid::Uuid;

pub struct TestCtx {
    pub app: Router,
    pub state: AppState,
}

impl TestCtx {
    /// Connect to Postgres + Redis from env. Returns `None` when infra is down
    /// so unit-only `cargo test` still succeeds without Docker.
    pub async fn connect() -> Option<Self> {
        dotenvy::dotenv().ok();
        let config = Config::for_tests();
        match tokio::time::timeout(
            std::time::Duration::from_secs(5),
            build_state(config),
        )
        .await
        {
            Ok(Ok(state)) => {
                let app = build_app(state.clone());
                Some(Self { app, state })
            }
            Ok(Err(err)) => {
                eprintln!("skipping integration tests: {err}");
                None
            }
            Err(_) => {
                eprintln!("skipping integration tests: timed out connecting to Postgres/Redis");
                None
            }
        }
    }

    pub async fn request(
        &self,
        method: &str,
        path: &str,
        token: Option<&str>,
        body: Option<Value>,
    ) -> (StatusCode, Value) {
        let mut builder = Request::builder().method(method).uri(path);
        if let Some(token) = token {
            builder = builder.header("Authorization", format!("Bearer {token}"));
        }
        let req = if let Some(body) = body {
            builder
                .header("Content-Type", "application/json")
                .body(Body::from(body.to_string()))
                .unwrap()
        } else {
            builder.body(Body::empty()).unwrap()
        };

        let response = self.app.clone().oneshot(req).await.expect("response");
        let status = response.status();
        let bytes = response
            .into_body()
            .collect()
            .await
            .expect("body")
            .to_bytes();
        let value = if bytes.is_empty() {
            Value::Null
        } else {
            serde_json::from_slice(&bytes).unwrap_or_else(|_| {
                json!({ "raw": String::from_utf8_lossy(&bytes) })
            })
        };
        (status, value)
    }

    pub async fn register_user(&self, prefix: &str) -> AuthUser {
        let suffix = &Uuid::new_v4().simple().to_string()[..12];
        let nickname = format!("{prefix}_{suffix}");
        let email = format!("{suffix}@test.local");
        let password = "password123";

        let (status, body) = self
            .request(
                "POST",
                "/auth/register",
                None,
                Some(json!({
                    "nickname": nickname,
                    "email": email,
                    "password": password,
                })),
            )
            .await;
        assert_eq!(status, StatusCode::OK, "register failed: {body}");
        AuthUser {
            nickname,
            email,
            password: password.into(),
            access_token: body["access_token"].as_str().unwrap().to_string(),
            refresh_token: body["refresh_token"].as_str().unwrap().to_string(),
        }
    }
}

pub struct AuthUser {
    pub nickname: String,
    pub email: String,
    pub password: String,
    pub access_token: String,
    pub refresh_token: String,
}
