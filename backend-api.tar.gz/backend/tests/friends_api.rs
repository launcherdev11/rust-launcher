mod common;

use axum::http::StatusCode;
use serde_json::json;

use common::TestCtx;

#[tokio::test]
async fn friends_request_accept_list_remove() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let alice = ctx.register_user("falice").await;
    let bob = ctx.register_user("fbob").await;

    let (status, sent) = ctx
        .request(
            "POST",
            "/friends/requests",
            Some(&alice.access_token),
            Some(json!({ "to_nickname": bob.nickname })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{sent}");
    assert_eq!(sent["success"], true);

    let (status, incoming) = ctx
        .request("GET", "/friends/requests", Some(&bob.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    let requests = incoming["incoming_requests"].as_array().unwrap();
    assert!(!requests.is_empty());
    let request_id = requests[0]["request_id"].as_str().unwrap();

    let (status, accepted) = ctx
        .request(
            "POST",
            &format!("/friends/requests/{request_id}/accept"),
            Some(&bob.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{accepted}");

    let (status, friends) = ctx
        .request("GET", "/friends", Some(&alice.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    let list = friends["friends"].as_array().unwrap();
    assert!(list.iter().any(|f| f["nickname"] == bob.nickname));

    let bob_id = list
        .iter()
        .find(|f| f["nickname"] == bob.nickname)
        .unwrap()["user_id"]
        .as_str()
        .unwrap()
        .to_string();

    let (status, removed) = ctx
        .request(
            "DELETE",
            &format!("/friends/{bob_id}"),
            Some(&alice.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{removed}");

    let (status, friends) = ctx
        .request("GET", "/friends", Some(&alice.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    assert!(!friends["friends"]
        .as_array()
        .unwrap()
        .iter()
        .any(|f| f["nickname"] == bob.nickname));
}

#[tokio::test]
async fn friends_reject_request() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let alice = ctx.register_user("frjal").await;
    let bob = ctx.register_user("frjbo").await;

    ctx.request(
        "POST",
        "/friends/requests",
        Some(&alice.access_token),
        Some(json!({ "to_nickname": bob.nickname })),
    )
    .await;

    let (_, incoming) = ctx
        .request("GET", "/friends/requests", Some(&bob.access_token), None)
        .await;
    let request_id = incoming["incoming_requests"][0]["request_id"]
        .as_str()
        .unwrap();

    let (status, _) = ctx
        .request(
            "POST",
            &format!("/friends/requests/{request_id}/reject"),
            Some(&bob.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK);

    let (status, friends) = ctx
        .request("GET", "/friends", Some(&bob.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    assert!(friends["friends"].as_array().unwrap().is_empty());
}
