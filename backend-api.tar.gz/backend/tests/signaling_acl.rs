use mc16launcher_api::ws::signaling::{can_signal_peer, parse_room_id, sdp_ok};
use uuid::Uuid;

#[test]
fn parse_room_id_rejects_garbage() {
    assert!(parse_room_id("not-a-uuid").is_none());
    let id = Uuid::new_v4();
    assert_eq!(parse_room_id(&id.to_string()), Some(id));
}

#[test]
fn sdp_ok_enforces_bounds() {
    assert!(!sdp_ok(""));
    assert!(sdp_ok("v=0"));
    let huge = "x".repeat(40_000);
    assert!(!sdp_ok(&huge));
}

#[tokio::test]
async fn can_signal_peer_requires_shared_room() {
    dotenvy::dotenv().ok();
    let config = mc16launcher_api::config::Config::for_tests();
    let Ok(state) = tokio::time::timeout(
        std::time::Duration::from_secs(5),
        mc16launcher_api::build_state(config),
    )
    .await
    else {
        return;
    };
    let Ok(state) = state else {
        return;
    };

    let a = Uuid::new_v4();
    let b = Uuid::new_v4();
    let room = Uuid::new_v4();
    // Non-existent room → false
    let ok = can_signal_peer(&state, room, a, b).await.expect("query");
    assert!(!ok);
}
