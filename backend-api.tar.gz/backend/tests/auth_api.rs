mod common;

use axum::http::StatusCode;
use serde_json::json;

use common::TestCtx;

#[tokio::test]
async fn health_ok() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let (status, body) = ctx.request("GET", "/health", None, None).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(body["status"], "ok");
    assert_eq!(body["service"], "mc16launcher-api");
}

#[tokio::test]
async fn openapi_and_docs_are_served() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let (status, body) = ctx.request("GET", "/openapi.yaml", None, None).await;
    assert_eq!(status, StatusCode::OK);
    let raw = body["raw"].as_str().unwrap_or_default();
    // YAML is not JSON; harness wraps non-JSON as { raw: "..." }.
    let text = if raw.is_empty() {
        body.to_string()
    } else {
        raw.to_string()
    };
    assert!(
        text.contains("openapi:") || text.contains("16Launcher"),
        "unexpected openapi body: {text}"
    );

    let (status, docs) = ctx.request("GET", "/docs", None, None).await;
    assert_eq!(status, StatusCode::OK);
    let docs_raw = docs["raw"].as_str().unwrap_or_default();
    assert!(docs_raw.contains("swagger-ui") || docs.to_string().contains("swagger-ui"));
}

#[tokio::test]
async fn auth_register_login_me_refresh_logout() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("auth").await;

    let (status, me) = ctx
        .request("GET", "/me", Some(&user.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(me["nickname"], user.nickname);
    assert_eq!(me["email"], user.email);

    let (status, tokens) = ctx
        .request(
            "POST",
            "/auth/login",
            None,
            Some(json!({
                "login": user.email,
                "password": user.password,
            })),
        )
        .await;
    assert_eq!(status, StatusCode::OK);
    assert!(tokens["access_token"].as_str().unwrap().len() > 10);

    let (status, refreshed) = ctx
        .request(
            "POST",
            "/auth/refresh",
            None,
            Some(json!({ "refresh_token": user.refresh_token })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "refresh: {refreshed}");
    let new_access = refreshed["access_token"].as_str().unwrap().to_string();

    let (status, _) = ctx
        .request("POST", "/auth/logout", Some(&new_access), None)
        .await;
    assert_eq!(status, StatusCode::OK);

    let (status, _) = ctx
        .request(
            "POST",
            "/auth/refresh",
            None,
            Some(json!({ "refresh_token": user.refresh_token })),
        )
        .await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn auth_rejects_duplicate_email() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("dup").await;
    let (status, body) = ctx
        .request(
            "POST",
            "/auth/register",
            None,
            Some(json!({
                "nickname": format!("other_{}", &uuid::Uuid::new_v4().simple().to_string()[..8]),
                "email": user.email,
                "password": "password123",
            })),
        )
        .await;
    assert_eq!(status, StatusCode::CONFLICT, "{body}");
}

#[tokio::test]
async fn auth_me_unauthorized_without_token() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let (status, _) = ctx.request("GET", "/me", None, None).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);
}
