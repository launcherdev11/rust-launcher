mod common;

use axum::http::StatusCode;
use serde_json::json;

use common::TestCtx;

#[tokio::test]
async fn turn_requires_auth_and_returns_shape() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("turn").await;

    let (unauth, _) = ctx.request("GET", "/network/turn", None, None).await;
    assert_eq!(unauth, StatusCode::UNAUTHORIZED);

    let (status, body) = ctx
        .request("GET", "/network/turn", Some(&user.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK, "turn failed: {body}");
    assert!(body["username"].as_str().unwrap().contains(':'));
    assert!(!body["password"].as_str().unwrap().is_empty());
    let ttl = body["ttl"].as_u64().unwrap();
    assert!(ttl >= 300 && ttl <= 600);
    let urls = body["urls"].as_array().unwrap();
    assert!(!urls.is_empty());
}

#[tokio::test]
async fn ice_servers_compatible_alias() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("ice").await;
    let (status, body) = ctx
        .request("GET", "/rtc/ice-servers", Some(&user.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK, "{body}");
    assert!(body["ice_servers"].as_array().is_some());
    assert!(body["ttl_secs"].as_u64().unwrap() <= 600);
}

#[tokio::test]
async fn room_session_created_and_member_only() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let owner = ctx.register_user("sess_o").await;
    let stranger = ctx.register_user("sess_s").await;

    let (status, body) = ctx
        .request(
            "POST",
            "/rooms",
            Some(&owner.access_token),
            Some(json!({ "max_players": 5 })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{body}");
    let room_id = body["room"]["id"].as_str().unwrap().to_string();

    let (s1, sess) = ctx
        .request(
            "GET",
            &format!("/rooms/{room_id}/session"),
            Some(&owner.access_token),
            None,
        )
        .await;
    assert_eq!(s1, StatusCode::OK, "{sess}");
    assert_eq!(sess["session"]["state"], "waiting");
    assert_eq!(sess["session"]["room_id"], room_id);

    let (s2, _) = ctx
        .request(
            "GET",
            &format!("/rooms/{room_id}/session"),
            Some(&stranger.access_token),
            None,
        )
        .await;
    assert_eq!(s2, StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn room_close_closes_session() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let owner = ctx.register_user("clos").await;
    let (status, body) = ctx
        .request(
            "POST",
            "/rooms",
            Some(&owner.access_token),
            Some(json!({ "max_players": 3 })),
        )
        .await;
    assert_eq!(status, StatusCode::OK);
    let room_id = body["room"]["id"].as_str().unwrap().to_string();

    let (c, _) = ctx
        .request(
            "DELETE",
            &format!("/rooms/{room_id}"),
            Some(&owner.access_token),
            None,
        )
        .await;
    assert_eq!(c, StatusCode::OK);

    // Owner is still a member of closed room for history? get_room may 404.
    // Session latest should be closed if membership still allows — after close,
    // members remain but room is closed. Endpoint requires membership.
    let (s, sess) = ctx
        .request(
            "GET",
            &format!("/rooms/{room_id}/session"),
            Some(&owner.access_token),
            None,
        )
        .await;
    assert_eq!(s, StatusCode::OK, "{sess}");
    assert_eq!(sess["session"]["state"], "closed");
}
