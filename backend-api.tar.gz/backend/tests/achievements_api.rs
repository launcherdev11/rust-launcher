mod common;

use axum::http::StatusCode;

use common::TestCtx;

#[tokio::test]
async fn achievements_catalog_and_unlock() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("ach").await;

    let (status, list) = ctx
        .request("GET", "/achievements", Some(&user.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK, "{list}");
    let achievements = list["achievements"].as_array().unwrap();
    assert!(!achievements.is_empty());

    let welcome = achievements
        .iter()
        .find(|a| a["code"] == "welcome")
        .expect("welcome achievement in catalog");
    assert_eq!(welcome["unlocked"], true);

    let target = achievements
        .iter()
        .find(|a| a["unlocked"] == false)
        .map(|a| a["code"].as_str().unwrap().to_string())
        .unwrap_or_else(|| "welcome".into());

    let (status, unlocked) = ctx
        .request(
            "POST",
            &format!("/achievements/{target}/unlock"),
            Some(&user.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{unlocked}");
    assert_eq!(unlocked["success"], true);

    let (status, missing) = ctx
        .request(
            "POST",
            "/achievements/does_not_exist_xyz/unlock",
            Some(&user.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::NOT_FOUND, "{missing}");
}

#[tokio::test]
async fn builds_endpoints_are_not_exposed() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("nobuild").await;

    for path in ["/builds", "/builds/00000000-0000-0000-0000-000000000001"] {
        let (status, _) = ctx
            .request("GET", path, Some(&user.access_token), None)
            .await;
        assert_eq!(
            status,
            StatusCode::NOT_FOUND,
            "builds API must stay removed: {path} -> {status}"
        );
    }
}
