mod common;

use axum::http::StatusCode;
use serde_json::json;

use common::TestCtx;

#[tokio::test]
async fn refresh_rotation_revokes_old_token() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("rot").await;
    let old_refresh = user.refresh_token.clone();

    let (status, body) = ctx
        .request(
            "POST",
            "/auth/refresh",
            None,
            Some(json!({ "refresh_token": old_refresh })),
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{body}");
    let new_refresh = body["refresh_token"].as_str().unwrap();
    assert_ne!(new_refresh, old_refresh);

    let (again, _) = ctx
        .request(
            "POST",
            "/auth/refresh",
            None,
            Some(json!({ "refresh_token": old_refresh })),
        )
        .await;
    assert_eq!(again, StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn logout_revokes_refresh_and_access_jti() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let user = ctx.register_user("out").await;

    let (lo, _) = ctx
        .request("POST", "/auth/logout", Some(&user.access_token), None)
        .await;
    assert_eq!(lo, StatusCode::OK);

    let (me, _) = ctx
        .request("GET", "/me", Some(&user.access_token), None)
        .await;
    assert_eq!(me, StatusCode::UNAUTHORIZED);

    let (ref_st, _) = ctx
        .request(
            "POST",
            "/auth/refresh",
            None,
            Some(json!({ "refresh_token": user.refresh_token })),
        )
        .await;
    assert_eq!(ref_st, StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn login_rate_limit_eventually_blocks() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    // Unique subject so we don't collide with other tests' counters.
    let login = format!("rl_{}", uuid::Uuid::new_v4().simple());
    let mut blocked = false;
    for _ in 0..30 {
        let (status, body) = ctx
            .request(
                "POST",
                "/auth/login",
                None,
                Some(json!({
                    "login": login,
                    "password": "password123",
                })),
            )
            .await;
        if status == StatusCode::BAD_REQUEST
            && body["error"].as_str() == Some("rate limit exceeded")
        {
            blocked = true;
            break;
        }
        // Unauthorized is expected for unknown user until rate limit trips.
        assert!(
            status == StatusCode::UNAUTHORIZED || status == StatusCode::BAD_REQUEST,
            "unexpected {status} {body}"
        );
    }
    assert!(blocked, "expected rate limit after repeated login attempts");
}
