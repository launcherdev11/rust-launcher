mod common;

use axum::http::StatusCode;
use serde_json::json;

use common::TestCtx;

#[tokio::test]
async fn notifications_list_and_mark_read() {
    let Some(ctx) = TestCtx::connect().await else {
        return;
    };
    let alice = ctx.register_user("nalice").await;
    let bob = ctx.register_user("nbob").await;

    ctx.request(
        "POST",
        "/friends/requests",
        Some(&alice.access_token),
        Some(json!({ "to_nickname": bob.nickname })),
    )
    .await;

    let (status, list) = ctx
        .request("GET", "/notifications", Some(&bob.access_token), None)
        .await;
    assert_eq!(status, StatusCode::OK);
    let notifications = list["notifications"].as_array().unwrap();
    assert!(!notifications.is_empty());
    assert!(notifications.iter().any(|n| n["type"] == "friend_request"));
    let id = notifications
        .iter()
        .find(|n| n["type"] == "friend_request")
        .unwrap()["id"]
        .as_str()
        .unwrap()
        .to_string();
    assert!(notifications
        .iter()
        .find(|n| n["id"] == id)
        .unwrap()["read_at"]
        .is_null());

    let (status, marked) = ctx
        .request(
            "PATCH",
            &format!("/notifications/{id}/read"),
            Some(&bob.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{marked}");

    let (_, list) = ctx
        .request("GET", "/notifications", Some(&bob.access_token), None)
        .await;
    let read_at = list["notifications"]
        .as_array()
        .unwrap()
        .iter()
        .find(|n| n["id"] == id)
        .unwrap()["read_at"]
        .clone();
    assert!(!read_at.is_null());

    let (status, all) = ctx
        .request(
            "PATCH",
            "/notifications/read-all",
            Some(&bob.access_token),
            None,
        )
        .await;
    assert_eq!(status, StatusCode::OK, "{all}");
    assert_eq!(all["success"], true);
}
