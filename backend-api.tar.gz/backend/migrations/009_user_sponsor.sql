-- Sponsor badge flag (Boosty / manual grant via admin panel).

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS is_sponsor BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_users_is_sponsor
    ON users (is_sponsor)
    WHERE is_sponsor = true;
