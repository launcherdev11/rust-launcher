CREATE TABLE launcher_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_name TEXT,
    platform TEXT,
    launcher_version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_ping TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at TIMESTAMPTZ
);

CREATE INDEX idx_launcher_sessions_user_open
    ON launcher_sessions (user_id)
    WHERE closed_at IS NULL;

CREATE INDEX idx_launcher_sessions_user_id
    ON launcher_sessions (user_id);
