CREATE TABLE user_stats (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    playtime_seconds BIGINT NOT NULL DEFAULT 0,
    launch_count BIGINT NOT NULL DEFAULT 0,
    first_launch_at TIMESTAMPTZ,
    last_launch_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT user_stats_playtime_nonneg CHECK (playtime_seconds >= 0),
    CONSTRAINT user_stats_launches_nonneg CHECK (launch_count >= 0)
);
