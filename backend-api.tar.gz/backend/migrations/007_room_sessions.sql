-- Room P2P connection sessions (e4mc-style signaling state).

CREATE TABLE room_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    host_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    state TEXT NOT NULL DEFAULT 'waiting',
    connection_type TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at TIMESTAMPTZ,
    CONSTRAINT room_sessions_state_check
        CHECK (state IN ('waiting', 'connecting', 'connected', 'failed', 'closed')),
    CONSTRAINT room_sessions_connection_type_check
        CHECK (connection_type IS NULL OR connection_type IN ('direct', 'relay')),
    CONSTRAINT room_sessions_closed_at_check
        CHECK (
            (state IN ('closed', 'failed') AND closed_at IS NOT NULL)
            OR (state NOT IN ('closed', 'failed') AND closed_at IS NULL)
        )
);

CREATE INDEX idx_room_sessions_room_id ON room_sessions(room_id);
CREATE INDEX idx_room_sessions_state ON room_sessions(state);
CREATE INDEX idx_room_sessions_host ON room_sessions(host_user_id);

-- At most one active session per room.
CREATE UNIQUE INDEX idx_room_sessions_one_active
    ON room_sessions(room_id)
    WHERE state IN ('waiting', 'connecting', 'connected');
