use serde_json::{json, Value};
use uuid::Uuid;

use crate::db::AppState;

pub async fn record(
    state: &AppState,
    user_id: Option<Uuid>,
    action: &str,
    meta: Value,
    ip: Option<&str>,
) {
    if let Err(e) = sqlx::query(
        r#"
        INSERT INTO audit_logs (user_id, action, meta, ip)
        VALUES ($1, $2, $3, $4)
        "#,
    )
    .bind(user_id)
    .bind(action)
    .bind(meta)
    .bind(ip)
    .execute(&state.pool)
    .await
    {
        tracing::warn!("audit log write failed for action={action}: {e}");
    }
}

pub async fn login(state: &AppState, user_id: Uuid, ip: Option<&str>) {
    record(state, Some(user_id), "login", json!({}), ip).await;
}

pub async fn logout(state: &AppState, user_id: Uuid, ip: Option<&str>) {
    record(state, Some(user_id), "logout", json!({}), ip).await;
}

pub async fn friend_accept(state: &AppState, user_id: Uuid, friend_user_id: Uuid) {
    record(
        state,
        Some(user_id),
        "friend_accept",
        json!({ "friend_user_id": friend_user_id }),
        None,
    )
    .await;
}

pub async fn room_create(state: &AppState, user_id: Uuid, room_id: Uuid) {
    record(
        state,
        Some(user_id),
        "room_create",
        json!({ "room_id": room_id }),
        None,
    )
    .await;
}

pub async fn room_close(state: &AppState, user_id: Uuid, room_id: Uuid) {
    record(
        state,
        Some(user_id),
        "room_close",
        json!({ "room_id": room_id }),
        None,
    )
    .await;
}

pub async fn turn_request(state: &AppState, user_id: Uuid) {
    //do not log TURN password/username secrets.
    record(state, Some(user_id), "turn_request", json!({}), None).await;
}
