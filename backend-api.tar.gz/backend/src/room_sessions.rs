//! Room P2P session lifecycle (waiting → connecting → connected | failed | closed).

use chrono::{DateTime, Utc};
use serde::Serialize;
use sqlx::Row;
use uuid::Uuid;

use crate::db::AppState;
use crate::error::ApiError;
use crate::ws::ConnectionType;
use crate::ws::WsEvent;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SessionState {
    Waiting,
    Connecting,
    Connected,
    Failed,
    Closed,
}

impl SessionState {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Waiting => "waiting",
            Self::Connecting => "connecting",
            Self::Connected => "connected",
            Self::Failed => "failed",
            Self::Closed => "closed",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "waiting" => Some(Self::Waiting),
            "connecting" => Some(Self::Connecting),
            "connected" => Some(Self::Connected),
            "failed" => Some(Self::Failed),
            "closed" => Some(Self::Closed),
            _ => None,
        }
    }

    pub fn is_terminal(self) -> bool {
        matches!(self, Self::Failed | Self::Closed)
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct RoomSessionRow {
    pub id: String,
    pub room_id: String,
    pub host_user_id: String,
    pub state: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub connection_type: Option<String>,
    pub created_at: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub closed_at: Option<String>,
}

fn map_row(row: &sqlx::postgres::PgRow) -> RoomSessionRow {
    RoomSessionRow {
        id: row.get::<Uuid, _>("id").to_string(),
        room_id: row.get::<Uuid, _>("room_id").to_string(),
        host_user_id: row.get::<Uuid, _>("host_user_id").to_string(),
        state: row.get("state"),
        connection_type: row.get::<Option<String>, _>("connection_type"),
        created_at: row
            .get::<DateTime<Utc>, _>("created_at")
            .to_rfc3339(),
        closed_at: row
            .get::<Option<DateTime<Utc>>, _>("closed_at")
            .map(|dt| dt.to_rfc3339()),
    }
}

/// Create a waiting session for a newly created room (idempotent if one active exists).
pub async fn ensure_waiting_session(
    state: &AppState,
    room_id: Uuid,
    host_user_id: Uuid,
) -> Result<RoomSessionRow, ApiError> {
    if let Some(existing) = get_active_session(state, room_id).await? {
        return Ok(existing);
    }

    let row = sqlx::query(
        r#"
        INSERT INTO room_sessions (room_id, host_user_id, state)
        VALUES ($1, $2, 'waiting')
        RETURNING id, room_id, host_user_id, state, connection_type, created_at, closed_at
        "#,
    )
    .bind(room_id)
    .bind(host_user_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(map_row(&row))
}

pub async fn get_active_session(
    state: &AppState,
    room_id: Uuid,
) -> Result<Option<RoomSessionRow>, ApiError> {
    let row = sqlx::query(
        r#"
        SELECT id, room_id, host_user_id, state, connection_type, created_at, closed_at
        FROM room_sessions
        WHERE room_id = $1
          AND state IN ('waiting', 'connecting', 'connected')
        ORDER BY created_at DESC
        LIMIT 1
        "#,
    )
    .bind(room_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(row.map(|r| map_row(&r)))
}

pub async fn get_latest_session(
    state: &AppState,
    room_id: Uuid,
) -> Result<Option<RoomSessionRow>, ApiError> {
    let row = sqlx::query(
        r#"
        SELECT id, room_id, host_user_id, state, connection_type, created_at, closed_at
        FROM room_sessions
        WHERE room_id = $1
        ORDER BY created_at DESC
        LIMIT 1
        "#,
    )
    .bind(room_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(row.map(|r| map_row(&r)))
}

pub async fn set_connecting(state: &AppState, room_id: Uuid) -> Result<(), ApiError> {
    sqlx::query(
        r#"
        UPDATE room_sessions
        SET state = 'connecting'
        WHERE room_id = $1
          AND state IN ('waiting', 'connecting')
        "#,
    )
    .bind(room_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(())
}

pub async fn mark_connected(
    state: &AppState,
    room_id: Uuid,
    connection_type: ConnectionType,
) -> Result<(), ApiError> {
    let ctype = match connection_type {
        ConnectionType::Direct => "direct",
        ConnectionType::Relay => "relay",
    };
    sqlx::query(
        r#"
        UPDATE room_sessions
        SET state = 'connected', connection_type = $2
        WHERE room_id = $1
          AND state IN ('waiting', 'connecting', 'connected')
        "#,
    )
    .bind(room_id)
    .bind(ctype)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(())
}

pub async fn mark_failed(state: &AppState, room_id: Uuid) -> Result<(), ApiError> {
    sqlx::query(
        r#"
        UPDATE room_sessions
        SET state = 'failed', closed_at = now()
        WHERE room_id = $1
          AND state IN ('waiting', 'connecting', 'connected')
        "#,
    )
    .bind(room_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(())
}

pub async fn close_active_sessions(
    state: &AppState,
    room_id: Uuid,
) -> Result<u64, ApiError> {
    let result = sqlx::query(
        r#"
        UPDATE room_sessions
        SET state = 'closed', closed_at = now()
        WHERE room_id = $1
          AND state IN ('waiting', 'connecting', 'connected')
        "#,
    )
    .bind(room_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(result.rows_affected())
}

/// Close sessions when the room has zero members or is closed.
pub async fn close_if_room_empty_or_closed(
    state: &AppState,
    room_id: Uuid,
) -> Result<(), ApiError> {
    let row = sqlx::query(
        r#"
        SELECT r.status,
               (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = r.id) AS member_count
        FROM rooms r
        WHERE r.id = $1
        "#,
    )
    .bind(room_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let Some(row) = row else {
        let _ = close_active_sessions(state, room_id).await?;
        return Ok(());
    };

    let status: String = row.get("status");
    let member_count: i32 = row.get("member_count");
    if status == "closed" || member_count <= 1 {
        // Alone host or empty / closed — no P2P peers left.
        if status == "closed" || member_count == 0 {
            let _ = close_active_sessions(state, room_id).await?;
        }
    }
    Ok(())
}

/// Reap stale sessions: room closed, empty, or no member has Redis presence.
pub async fn reap_stale_sessions(state: &AppState) -> Result<u64, ApiError> {
    // Close sessions for closed rooms.
    let closed_rooms = sqlx::query(
        r#"
        UPDATE room_sessions rs
        SET state = 'closed', closed_at = now()
        FROM rooms r
        WHERE rs.room_id = r.id
          AND r.status = 'closed'
          AND rs.state IN ('waiting', 'connecting', 'connected')
        "#,
    )
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    // Close sessions for empty rooms.
    let empty = sqlx::query(
        r#"
        UPDATE room_sessions rs
        SET state = 'closed', closed_at = now()
        WHERE rs.state IN ('waiting', 'connecting', 'connected')
          AND NOT EXISTS (
              SELECT 1 FROM room_members m WHERE m.room_id = rs.room_id
          )
        "#,
    )
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    // Waiting/connecting without any online member (presence heartbeat missing).
    let active = sqlx::query(
        r#"
        SELECT rs.id, rs.room_id
        FROM room_sessions rs
        WHERE rs.state IN ('waiting', 'connecting')
        "#,
    )
    .fetch_all(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let mut heartbeat_closed = 0u64;
    for row in active {
        let session_id: Uuid = row.get("id");
        let room_id: Uuid = row.get("room_id");
        let members = sqlx::query_scalar::<_, Uuid>(
            "SELECT user_id FROM room_members WHERE room_id = $1",
        )
        .bind(room_id)
        .fetch_all(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

        if members.is_empty() {
            continue;
        }

        let mut any_online = false;
        for uid in &members {
            if crate::presence::is_online(state, *uid).await.unwrap_or(false) {
                any_online = true;
                break;
            }
        }

        if !any_online {
            let res = sqlx::query(
                r#"
                UPDATE room_sessions
                SET state = 'closed', closed_at = now()
                WHERE id = $1 AND state IN ('waiting', 'connecting')
                "#,
            )
            .bind(session_id)
            .execute(&state.pool)
            .await
            .map_err(|e| ApiError::Internal(e.to_string()))?;
            heartbeat_closed += res.rows_affected();
        }
    }

    Ok(closed_rooms.rows_affected() + empty.rows_affected() + heartbeat_closed)
}

pub async fn notify_session_event(state: &AppState, room_id: Uuid, event: WsEvent) {
    match sqlx::query_scalar::<_, Uuid>("SELECT user_id FROM room_members WHERE room_id = $1")
        .bind(room_id)
        .fetch_all(&state.pool)
        .await
    {
        Ok(members) => state.ws.send_to_users(members, event).await,
        Err(e) => tracing::warn!("session notify failed: {e}"),
    }
}

/// Background loop — reap stale room sessions periodically.
pub fn spawn_reaper(state: AppState) {
    tokio::spawn(async move {
        let mut tick = tokio::time::interval(std::time::Duration::from_secs(30));
        loop {
            tick.tick().await;
            if let Err(e) = reap_stale_sessions(&state).await {
                tracing::warn!("room_sessions reaper: {e}");
            }
        }
    });
}
