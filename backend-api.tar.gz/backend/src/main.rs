use std::net::SocketAddr;

use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

use mc16launcher_api::config::Config;
use mc16launcher_api::{build_app, build_state};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    dotenvy::dotenv().ok();

    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "mc16launcher_api=info,tower_http=info".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    let config = Config::from_env()?;
    let state = build_state(config.clone()).await?;
    mc16launcher_api::room_sessions::spawn_reaper(state.clone());
    let app = build_app(state);

    let addr: SocketAddr = config.listen_addr.parse()?;
    tracing::info!(
        "16Launcher API listening on {addr} (presence timeout {}s)",
        config.presence_timeout_secs
    );
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
