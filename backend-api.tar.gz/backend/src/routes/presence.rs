use axum::{
    extract::State,
    routing::{get, post},
    Json, Router,
};
use serde::Serialize;
use sqlx::Row;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;
use crate::presence::{self, PresenceInfo};
use crate::ws::WsEvent;

#[derive(Serialize)]
struct PresenceResponse {
    presence: PresenceInfo,
}

#[derive(Serialize)]
struct FriendsPresenceResponse {
    presence: Vec<PresenceInfo>,
}

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/presence/heartbeat", post(heartbeat))
        .route("/presence/offline", post(go_offline))
        .route("/presence/me", get(me))
        .route("/presence/friends", get(friends_presence))
}

async fn friend_ids(state: &AppState, user_id: Uuid) -> Result<Vec<Uuid>, ApiError> {
    let rows = sqlx::query("SELECT friend_user_id FROM friends WHERE user_id = $1")
        .bind(user_id)
        .fetch_all(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(rows
        .into_iter()
        .map(|row| row.get::<Uuid, _>("friend_user_id"))
        .collect())
}

async fn heartbeat(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<PresenceResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let was_online = presence::get_presence(&state, user_id).await?.online;
    let presence = presence::heartbeat(&state, user_id).await?;
    if !was_online {
        let nickname: Option<String> =
            sqlx::query_scalar("SELECT nickname FROM users WHERE id = $1")
                .bind(user_id)
                .fetch_optional(&state.pool)
                .await
                .ok()
                .flatten();
        let friends = friend_ids(&state, user_id).await.unwrap_or_default();
        state
            .ws
            .send_to_users(
                friends,
                WsEvent::UserOnline {
                    user_id: user_id.to_string(),
                    nickname,
                },
            )
            .await;
    }
    Ok(Json(PresenceResponse { presence }))
}

async fn go_offline(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<PresenceResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let presence = presence::set_offline(&state, user_id).await?;
    let friends = friend_ids(&state, user_id).await.unwrap_or_default();
    state
        .ws
        .send_to_users(
            friends,
            WsEvent::UserOffline {
                user_id: user_id.to_string(),
                last_seen: presence.last_seen.clone(),
            },
        )
        .await;
    Ok(Json(PresenceResponse { presence }))
}

async fn me(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<PresenceResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let presence = presence::get_presence(&state, user_id).await?;
    Ok(Json(PresenceResponse { presence }))
}

async fn friends_presence(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<FriendsPresenceResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let rows = sqlx::query(
        "SELECT friend_user_id FROM friends WHERE user_id = $1 ORDER BY friend_user_id",
    )
    .bind(user_id)
    .fetch_all(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let friend_ids: Vec<Uuid> = rows
        .into_iter()
        .map(|row| row.get::<Uuid, _>("friend_user_id"))
        .collect();

    let presence = presence::get_many(&state, &friend_ids).await?;
    Ok(Json(FriendsPresenceResponse { presence }))
}
