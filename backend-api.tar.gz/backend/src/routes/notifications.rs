use axum::{
    extract::{Path, State},
    routing::{get, patch},
    Json, Router,
};
use serde::Serialize;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;
use crate::notifications::{self, NotificationRow};

#[derive(Serialize)]
struct ListResponse {
    notifications: Vec<NotificationRow>,
}

#[derive(Serialize)]
struct SuccessResponse {
    success: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    updated: Option<u64>,
}

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/notifications", get(list_notifications))
        .route("/notifications/read-all", patch(read_all))
        .route("/notifications/{id}/read", patch(read_one))
}

async fn list_notifications(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<ListResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let notifications = notifications::list_for_user(&state, user_id, 50).await?;
    Ok(Json(ListResponse { notifications }))
}

async fn read_one(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Path(id): Path<Uuid>,
) -> Result<Json<SuccessResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    notifications::mark_read(&state, user_id, id).await?;
    Ok(Json(SuccessResponse {
        success: true,
        updated: None,
    }))
}

async fn read_all(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<SuccessResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let updated = notifications::mark_all_read(&state, user_id).await?;
    Ok(Json(SuccessResponse {
        success: true,
        updated: Some(updated),
    }))
}
