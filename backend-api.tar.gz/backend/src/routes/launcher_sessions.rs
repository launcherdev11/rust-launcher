use axum::{
    extract::{Path, State},
    routing::post,
    Json, Router,
};
use serde::{Deserialize, Serialize};
use sqlx::Row;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;
use crate::presence;
use crate::ws::WsEvent;

#[derive(Deserialize)]
pub struct CreateSessionBody {
    #[serde(default)]
    pub device_name: Option<String>,
    #[serde(default)]
    pub platform: Option<String>,
    #[serde(default)]
    pub launcher_version: Option<String>,
}

#[derive(Serialize)]
pub struct SessionRow {
    pub id: String,
    pub user_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub device_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub platform: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub launcher_version: Option<String>,
    pub created_at: String,
    pub last_ping: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub closed_at: Option<String>,
}

#[derive(Serialize)]
struct SessionResponse {
    session: SessionRow,
}

#[derive(Serialize)]
struct SuccessResponse {
    success: bool,
}

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/launcher/sessions", post(create_session))
        .route("/launcher/sessions/{id}/ping", post(ping_session))
        .route("/launcher/sessions/{id}/close", post(close_session))
}

fn map_session(row: &sqlx::postgres::PgRow) -> SessionRow {
    SessionRow {
        id: row.get::<Uuid, _>("id").to_string(),
        user_id: row.get::<Uuid, _>("user_id").to_string(),
        device_name: row.get("device_name"),
        platform: row.get("platform"),
        launcher_version: row.get("launcher_version"),
        created_at: row
            .get::<chrono::DateTime<chrono::Utc>, _>("created_at")
            .to_rfc3339(),
        last_ping: row
            .get::<chrono::DateTime<chrono::Utc>, _>("last_ping")
            .to_rfc3339(),
        closed_at: row
            .get::<Option<chrono::DateTime<chrono::Utc>>, _>("closed_at")
            .map(|dt| dt.to_rfc3339()),
    }
}

async fn open_session_count(state: &AppState, user_id: Uuid) -> Result<i64, ApiError> {
    sqlx::query_scalar(
        "SELECT COUNT(*) FROM launcher_sessions WHERE user_id = $1 AND closed_at IS NULL",
    )
    .bind(user_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))
}

async fn notify_online(state: &AppState, user_id: Uuid) {
    let nickname: Option<String> = sqlx::query_scalar("SELECT nickname FROM users WHERE id = $1")
        .bind(user_id)
        .fetch_optional(&state.pool)
        .await
        .ok()
        .flatten();
    let friends = sqlx::query("SELECT friend_user_id FROM friends WHERE user_id = $1")
        .bind(user_id)
        .fetch_all(&state.pool)
        .await
        .unwrap_or_default();
    let friend_ids: Vec<Uuid> = friends
        .into_iter()
        .map(|row| row.get::<Uuid, _>("friend_user_id"))
        .collect();
    state
        .ws
        .send_to_users(
            friend_ids,
            WsEvent::UserOnline {
                user_id: user_id.to_string(),
                nickname,
            },
        )
        .await;
}

async fn notify_offline(state: &AppState, user_id: Uuid, last_seen: Option<String>) {
    let friends = sqlx::query("SELECT friend_user_id FROM friends WHERE user_id = $1")
        .bind(user_id)
        .fetch_all(&state.pool)
        .await
        .unwrap_or_default();
    let friend_ids: Vec<Uuid> = friends
        .into_iter()
        .map(|row| row.get::<Uuid, _>("friend_user_id"))
        .collect();
    state
        .ws
        .send_to_users(
            friend_ids,
            WsEvent::UserOffline {
                user_id: user_id.to_string(),
                last_seen,
            },
        )
        .await;
}

async fn create_session(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<CreateSessionBody>,
) -> Result<Json<SessionResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let row = sqlx::query(
        r#"
        INSERT INTO launcher_sessions (user_id, device_name, platform, launcher_version)
        VALUES ($1, $2, $3, $4)
        RETURNING id, user_id, device_name, platform, launcher_version, created_at, last_ping, closed_at
        "#,
    )
    .bind(user_id)
    .bind(body.device_name.as_deref().map(str::trim).filter(|s| !s.is_empty()))
    .bind(body.platform.as_deref().map(str::trim).filter(|s| !s.is_empty()))
    .bind(
        body.launcher_version
            .as_deref()
            .map(str::trim)
            .filter(|s| !s.is_empty()),
    )
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let was_online = presence::get_presence(&state, user_id).await?.online;
    let _ = presence::heartbeat(&state, user_id).await?;
    if !was_online {
        notify_online(&state, user_id).await;
    }

    Ok(Json(SessionResponse {
        session: map_session(&row),
    }))
}

async fn ping_session(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Path(session_id): Path<Uuid>,
) -> Result<Json<SessionResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let row = sqlx::query(
        r#"
        UPDATE launcher_sessions
        SET last_ping = now()
        WHERE id = $1 AND user_id = $2 AND closed_at IS NULL
        RETURNING id, user_id, device_name, platform, launcher_version, created_at, last_ping, closed_at
        "#,
    )
    .bind(session_id)
    .bind(user_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?
    .ok_or(ApiError::NotFound)?;

    let _ = presence::heartbeat(&state, user_id).await?;

    Ok(Json(SessionResponse {
        session: map_session(&row),
    }))
}

async fn close_session(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Path(session_id): Path<Uuid>,
) -> Result<Json<SuccessResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let result = sqlx::query(
        r#"
        UPDATE launcher_sessions
        SET closed_at = now(), last_ping = now()
        WHERE id = $1 AND user_id = $2 AND closed_at IS NULL
        "#,
    )
    .bind(session_id)
    .bind(user_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if result.rows_affected() == 0 {
        return Err(ApiError::NotFound);
    }

    let open = open_session_count(&state, user_id).await?;
    if open == 0 && !state.ws.is_connected(user_id).await {
        let presence = presence::set_offline(&state, user_id).await?;
        notify_offline(&state, user_id, presence.last_seen).await;
    }

    Ok(Json(SuccessResponse { success: true }))
}
