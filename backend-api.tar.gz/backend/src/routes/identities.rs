use axum::{extract::State, routing::post, Json, Router};
use serde::{Deserialize, Serialize};
use sqlx::Row;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;

#[derive(Deserialize)]
pub struct LinkIdentityBody {
    pub provider: String,
    pub provider_uuid: String,
    #[serde(default)]
    pub provider_username: Option<String>,
    /// Live Ely OAuth / Yggdrasil or Minecraft Services access token used as ownership proof.
    #[serde(default)]
    pub provider_access_token: Option<String>,
    /// Required for Ely Yggdrasil (password-login) tokens when OAuth account-info is unavailable.
    #[serde(default)]
    pub provider_client_token: Option<String>,
}

#[derive(Serialize)]
struct LinkIdentityResponse {
    success: bool,
}

struct VerifiedIdentity {
    provider_user_id: String,
    username: Option<String>,
}

pub fn router() -> Router<AppState> {
    Router::new().route("/identities/link", post(link_identity))
}

async fn link_identity(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<LinkIdentityBody>,
) -> Result<Json<LinkIdentityResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let provider = body.provider.trim().to_lowercase();
    if provider != "ely" && provider != "minecraft" {
        return Err(ApiError::bad_request("unsupported provider"));
    }

    let claimed_uuid = normalize_provider_uuid(&body.provider_uuid);
    if claimed_uuid.is_empty() {
        return Err(ApiError::bad_request("provider_uuid is empty"));
    }

    let verified = if state.config.require_identity_proof {
        let access_token = body
            .provider_access_token
            .as_deref()
            .map(str::trim)
            .filter(|t| !t.is_empty())
            .ok_or_else(|| {
                ApiError::bad_request("provider_access_token is required to prove identity ownership")
            })?;
        let verified = verify_provider_identity(
            &provider,
            access_token,
            body.provider_client_token.as_deref(),
        )
        .await?;
        if verified.provider_user_id != claimed_uuid {
            return Err(ApiError::bad_request(
                "provider_uuid does not match the verified provider account",
            ));
        }
        verified
    } else {
        VerifiedIdentity {
            provider_user_id: claimed_uuid.clone(),
            username: body
                .provider_username
                .as_ref()
                .map(|n| n.trim().to_string())
                .filter(|n| !n.is_empty()),
        }
    };

    let provider_user_id = verified.provider_user_id;
    let metadata = verified
        .username
        .or_else(|| {
            body.provider_username
                .as_ref()
                .map(|n| n.trim().to_string())
                .filter(|n| !n.is_empty())
        })
        .map(|username| serde_json::json!({ "username": username }));

    let existing = sqlx::query(
        "SELECT user_id FROM user_identities WHERE provider = $1 AND provider_user_id = $2",
    )
    .bind(&provider)
    .bind(&provider_user_id)
    .fetch_optional(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if let Some(row) = existing {
        let owner: Uuid = row.get("user_id");
        if owner != user_id {
            return Err(ApiError::Conflict(
                "identity already linked to another user".into(),
            ));
        }
        sqlx::query(
            r#"
            UPDATE user_identities
            SET access_metadata = COALESCE($3, access_metadata)
            WHERE provider = $1 AND provider_user_id = $2 AND user_id = $4
            "#,
        )
        .bind(&provider)
        .bind(&provider_user_id)
        .bind(metadata)
        .bind(user_id)
        .execute(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    } else {
        sqlx::query(
            r#"
            INSERT INTO user_identities (user_id, provider, provider_user_id, access_metadata)
            VALUES ($1, $2, $3, $4)
            "#,
        )
        .bind(user_id)
        .bind(&provider)
        .bind(&provider_user_id)
        .bind(metadata)
        .execute(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

        let _ = crate::achievements::try_unlock(&state.pool, user_id, "identity_linked").await;
    }

    Ok(Json(LinkIdentityResponse { success: true }))
}

fn normalize_provider_uuid(raw: &str) -> String {
    raw.trim().to_lowercase().replace('-', "")
}

async fn verify_provider_identity(
    provider: &str,
    access_token: &str,
    client_token: Option<&str>,
) -> Result<VerifiedIdentity, ApiError> {
    match provider {
        "ely" => verify_ely_identity(access_token, client_token).await,
        "minecraft" => verify_minecraft_identity(access_token).await,
        _ => Err(ApiError::bad_request("unsupported provider")),
    }
}

async fn verify_ely_identity(
    access_token: &str,
    client_token: Option<&str>,
) -> Result<VerifiedIdentity, ApiError> {
    let client = http_client()?;

    // OAuth2 account_info scope.
    let oauth = client
        .get("https://account.ely.by/api/account/v1/info")
        .bearer_auth(access_token)
        .send()
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    if oauth.status().is_success() {
        let info: ElyAccountInfo = oauth
            .json()
            .await
            .map_err(|_| ApiError::bad_request("invalid Ely account info response"))?;
        let provider_user_id = normalize_provider_uuid(&info.uuid);
        if provider_user_id.is_empty() {
            return Err(ApiError::bad_request("Ely account has empty uuid"));
        }
        return Ok(VerifiedIdentity {
            provider_user_id,
            username: Some(info.username).filter(|u| !u.is_empty()),
        });
    }

    // Yggdrasil password-login tokens: refresh returns selectedProfile.
    let client_token = client_token
        .map(str::trim)
        .filter(|t| !t.is_empty())
        .ok_or_else(|| {
            ApiError::bad_request(
                "provider_client_token is required for Ely Yggdrasil sessions",
            )
        })?;

    let refresh = client
        .post("https://authserver.ely.by/auth/refresh")
        .json(&serde_json::json!({
            "accessToken": access_token,
            "clientToken": client_token,
            "requestUser": false,
        }))
        .send()
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    if !refresh.status().is_success() {
        return Err(ApiError::Unauthorized);
    }

    let body: ElyYggdrasilRefresh = refresh
        .json()
        .await
        .map_err(|_| ApiError::bad_request("invalid Ely refresh response"))?;
    let profile = body
        .selected_profile
        .ok_or_else(|| ApiError::bad_request("Ely refresh response missing selectedProfile"))?;
    let provider_user_id = normalize_provider_uuid(&profile.id);
    if provider_user_id.is_empty() {
        return Err(ApiError::bad_request("Ely profile has empty uuid"));
    }
    Ok(VerifiedIdentity {
        provider_user_id,
        username: Some(profile.name).filter(|u| !u.is_empty()),
    })
}

async fn verify_minecraft_identity(access_token: &str) -> Result<VerifiedIdentity, ApiError> {
    let client = http_client()?;
    let resp = client
        .get("https://api.minecraftservices.com/minecraft/profile")
        .bearer_auth(access_token)
        .send()
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    if resp.status() == reqwest::StatusCode::UNAUTHORIZED
        || resp.status() == reqwest::StatusCode::FORBIDDEN
    {
        return Err(ApiError::Unauthorized);
    }
    if !resp.status().is_success() {
        return Err(ApiError::bad_request("failed to verify Minecraft identity"));
    }

    let profile: MinecraftProfile = resp
        .json()
        .await
        .map_err(|_| ApiError::bad_request("invalid Minecraft profile response"))?;
    let provider_user_id = normalize_provider_uuid(&profile.id);
    if provider_user_id.is_empty() {
        return Err(ApiError::bad_request("Minecraft profile has empty uuid"));
    }
    Ok(VerifiedIdentity {
        provider_user_id,
        username: Some(profile.name).filter(|u| !u.is_empty()),
    })
}

fn http_client() -> Result<reqwest::Client, ApiError> {
    reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(10))
        .user_agent("mc16launcher-api/0.1")
        .build()
        .map_err(|e| ApiError::Internal(e.to_string()))
}

#[derive(Deserialize)]
struct ElyAccountInfo {
    uuid: String,
    username: String,
}

#[derive(Deserialize)]
struct ElyYggdrasilRefresh {
    #[serde(rename = "selectedProfile")]
    selected_profile: Option<ElyYggdrasilProfile>,
}

#[derive(Deserialize)]
struct ElyYggdrasilProfile {
    id: String,
    name: String,
}

#[derive(Deserialize)]
struct MinecraftProfile {
    id: String,
    name: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn normalize_strips_dashes_and_case() {
        assert_eq!(
            normalize_provider_uuid("A1B2C3D4-E5F6-7890-ABCD-EF1234567890"),
            "a1b2c3d4e5f67890abcdef1234567890"
        );
    }
}
