use axum::{extract::State, routing::get, Json, Router};
use base64::Engine;
use hmac::{Hmac, Mac};
use serde::Serialize;
use sha1::Sha1;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;

type HmacSha1 = Hmac<Sha1>;

/// Network TURN response — short-lived REST credentials for coturn.
#[derive(Serialize)]
pub struct TurnCredentialsResponse {
    pub username: String,
    pub password: String,
    pub ttl: u64,
    pub urls: Vec<String>,
}

#[derive(Serialize)]
pub struct IceServer {
    pub urls: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub username: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub credential: Option<String>,
}

#[derive(Serialize)]
struct IceServersResponse {
    ice_servers: Vec<IceServer>,
    ttl_secs: u64,
    realm: String,
}

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/network/turn", get(network_turn))
        .route("/rtc/ice-servers", get(ice_servers))
}

/// Clamp TURN credential lifetime to 5–10 minutes for `/network/turn`.
fn network_turn_ttl(configured: u64) -> u64 {
    configured.clamp(300, 600)
}

async fn network_turn(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<TurnCredentialsResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    crate::rate_limit::check(&state, crate::rate_limit::TURN, &user_id.to_string()).await?;

    let host = state.config.turn_host.trim();
    if host.is_empty() {
        return Err(ApiError::bad_request("TURN is not configured"));
    }

    let ttl = network_turn_ttl(state.config.turn_ttl_secs);
    let (username, password) = mint_turn_credentials(&state.config.turn_secret, user_id, ttl)?;
    let urls = turn_urls(host);

    crate::audit::turn_request(&state, user_id).await;

    Ok(Json(TurnCredentialsResponse {
        username,
        password,
        ttl,
        urls,
    }))
}

async fn ice_servers(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<IceServersResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    crate::rate_limit::check(&state, crate::rate_limit::TURN, &user_id.to_string()).await?;
    let mut ice_servers = Vec::new();

    if !state.config.stun_urls.is_empty() {
        ice_servers.push(IceServer {
            urls: state.config.stun_urls.clone(),
            username: None,
            credential: None,
        });
    }

    let ttl = network_turn_ttl(state.config.turn_ttl_secs);
    if !state.config.turn_host.trim().is_empty() {
        let (username, credential) =
            mint_turn_credentials(&state.config.turn_secret, user_id, ttl)?;
        ice_servers.push(IceServer {
            urls: turn_urls(state.config.turn_host.trim()),
            username: Some(username),
            credential: Some(credential),
        });
    }

    Ok(Json(IceServersResponse {
        ice_servers,
        ttl_secs: ttl,
        realm: state.config.turn_realm.clone(),
    }))
}

fn turn_urls(host: &str) -> Vec<String> {
    vec![
        format!("turn:{host}:3478?transport=udp"),
        format!("turn:{host}:3478?transport=tcp"),
    ]
}

/// coturn `use-auth-secret` / TURN REST credentials (HMAC-SHA1).
pub fn mint_turn_credentials(
    secret: &str,
    user_id: Uuid,
    ttl_secs: u64,
) -> Result<(String, String), ApiError> {
    let expiry = chrono::Utc::now().timestamp() + ttl_secs as i64;
    let username = format!("{expiry}:{user_id}");
    let mut mac = HmacSha1::new_from_slice(secret.as_bytes())
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    mac.update(username.as_bytes());
    let password = base64::engine::general_purpose::STANDARD.encode(mac.finalize().into_bytes());
    Ok((username, password))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn turn_credentials_are_deterministic_for_same_inputs() {
        let user = Uuid::nil();
        let (username, credential) = mint_turn_credentials("secret", user, 3600).unwrap();
        assert!(username.contains(&user.to_string()));
        assert!(username.contains(':'));
        assert!(!credential.is_empty());

        let mut mac = HmacSha1::new_from_slice(b"secret").unwrap();
        mac.update(username.as_bytes());
        let expected =
            base64::engine::general_purpose::STANDARD.encode(mac.finalize().into_bytes());
        assert_eq!(credential, expected);
    }

    #[test]
    fn network_turn_ttl_clamped_to_5_10_minutes() {
        assert_eq!(network_turn_ttl(60), 300);
        assert_eq!(network_turn_ttl(450), 450);
        assert_eq!(network_turn_ttl(86_400), 600);
    }
}
