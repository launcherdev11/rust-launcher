mod achievements;
mod auth;
mod friends;
mod health;
mod identities;
mod launcher_sessions;
mod notifications;
mod openapi;
mod presence;
mod room_sessions;
mod rooms;
mod rtc;
mod stats;
mod users;

use axum::Router;

use crate::db::AppState;

pub fn router() -> Router<AppState> {
    Router::new()
        .merge(health::router())
        .merge(openapi::router())
        .merge(auth::router())
        .merge(friends::router())
        .merge(users::router())
        .merge(identities::router())
        .merge(achievements::router())
        .merge(rooms::router())
        .merge(room_sessions::router())
        .merge(presence::router())
        .merge(notifications::router())
        .merge(launcher_sessions::router())
        .merge(stats::router())
        .merge(rtc::router())
        .merge(crate::ws::router())
}
