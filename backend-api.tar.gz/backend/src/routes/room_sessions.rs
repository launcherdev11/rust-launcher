use axum::{
    extract::{Path, State},
    routing::get,
    Json, Router,
};
use serde::Serialize;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;
use crate::room_sessions::{self, RoomSessionRow};

#[derive(Serialize)]
struct SessionResponse {
    session: Option<RoomSessionRow>,
}

pub fn router() -> Router<AppState> {
    Router::new().route("/rooms/{id}/session", get(get_room_session))
}

async fn get_room_session(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Path(room_id): Path<Uuid>,
) -> Result<Json<SessionResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;

    let is_member = sqlx::query_scalar::<_, i64>(
        "SELECT COUNT(*) FROM room_members WHERE room_id = $1 AND user_id = $2",
    )
    .bind(room_id)
    .bind(user_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if is_member == 0 {
        return Err(ApiError::Unauthorized);
    }

    let session = room_sessions::get_latest_session(&state, room_id).await?;
    Ok(Json(SessionResponse { session }))
}
