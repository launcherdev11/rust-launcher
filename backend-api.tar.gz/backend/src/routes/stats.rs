use axum::{
    extract::State,
    routing::{get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use sqlx::Row;
use uuid::Uuid;

use crate::auth::extract_user_id;
use crate::db::AppState;
use crate::error::ApiError;

#[derive(Serialize)]
pub struct UserStats {
    pub user_id: String,
    pub playtime_seconds: i64,
    pub launch_count: i64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub first_launch_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_launch_at: Option<String>,
}

#[derive(Serialize)]
struct StatsResponse {
    stats: UserStats,
}

#[derive(Deserialize)]
pub struct ReportStatsBody {
    /// Seconds of playtime to add (launcher-reported delta).
    #[serde(default)]
    pub playtime_seconds_delta: Option<i64>,
    /// Absolute playtime override (optional; used if delta is absent).
    #[serde(default)]
    pub playtime_seconds: Option<i64>,
    /// Increment launch_count by 1 when true.
    #[serde(default)]
    pub launched: bool,
}

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/stats/me", get(get_my_stats))
        .route("/stats/report", post(report_stats))
}

fn map_stats(row: &sqlx::postgres::PgRow) -> UserStats {
    UserStats {
        user_id: row.get::<Uuid, _>("user_id").to_string(),
        playtime_seconds: row.get("playtime_seconds"),
        launch_count: row.get("launch_count"),
        first_launch_at: row
            .get::<Option<chrono::DateTime<chrono::Utc>>, _>("first_launch_at")
            .map(|dt| dt.to_rfc3339()),
        last_launch_at: row
            .get::<Option<chrono::DateTime<chrono::Utc>>, _>("last_launch_at")
            .map(|dt| dt.to_rfc3339()),
    }
}

async fn ensure_stats_row(state: &AppState, user_id: Uuid) -> Result<(), ApiError> {
    sqlx::query(
        r#"
        INSERT INTO user_stats (user_id)
        VALUES ($1)
        ON CONFLICT (user_id) DO NOTHING
        "#,
    )
    .bind(user_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(())
}

async fn fetch_stats(state: &AppState, user_id: Uuid) -> Result<UserStats, ApiError> {
    ensure_stats_row(state, user_id).await?;
    let row = sqlx::query(
        r#"
        SELECT user_id, playtime_seconds, launch_count, first_launch_at, last_launch_at
        FROM user_stats
        WHERE user_id = $1
        "#,
    )
    .bind(user_id)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(map_stats(&row))
}

async fn get_my_stats(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
) -> Result<Json<StatsResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    let stats = fetch_stats(&state, user_id).await?;
    Ok(Json(StatsResponse { stats }))
}

async fn report_stats(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(body): Json<ReportStatsBody>,
) -> Result<Json<StatsResponse>, ApiError> {
    let user_id = extract_user_id(&state, &headers).await?;
    ensure_stats_row(&state, user_id).await?;

    if let Some(abs) = body.playtime_seconds {
        if abs < 0 {
            return Err(ApiError::bad_request("playtime_seconds must be >= 0"));
        }
        sqlx::query(
            r#"
            UPDATE user_stats
            SET playtime_seconds = GREATEST(playtime_seconds, $2),
                updated_at = now()
            WHERE user_id = $1
            "#,
        )
        .bind(user_id)
        .bind(abs)
        .execute(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    } else if let Some(delta) = body.playtime_seconds_delta {
        if delta < 0 {
            return Err(ApiError::bad_request("playtime_seconds_delta must be >= 0"));
        }
        if delta > 0 {
            sqlx::query(
                r#"
                UPDATE user_stats
                SET playtime_seconds = playtime_seconds + $2,
                    updated_at = now()
                WHERE user_id = $1
                "#,
            )
            .bind(user_id)
            .bind(delta)
            .execute(&state.pool)
            .await
            .map_err(|e| ApiError::Internal(e.to_string()))?;
        }
    }

    if body.launched {
        sqlx::query(
            r#"
            UPDATE user_stats
            SET launch_count = launch_count + 1,
                first_launch_at = COALESCE(first_launch_at, now()),
                last_launch_at = now(),
                updated_at = now()
            WHERE user_id = $1
            "#,
        )
        .bind(user_id)
        .execute(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    } else if body.playtime_seconds_delta.unwrap_or(0) > 0
        || body.playtime_seconds.is_some()
    {
        // Touch last_launch when reporting playtime without a new launch flag.
        sqlx::query(
            r#"
            UPDATE user_stats
            SET last_launch_at = COALESCE(last_launch_at, now()),
                first_launch_at = COALESCE(first_launch_at, now()),
                updated_at = now()
            WHERE user_id = $1
            "#,
        )
        .bind(user_id)
        .execute(&state.pool)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    }

    let stats = fetch_stats(&state, user_id).await?;
    Ok(Json(StatsResponse { stats }))
}
