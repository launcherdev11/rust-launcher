pub mod achievements;
pub mod auth;
pub mod config;
pub mod db;
pub mod error;
pub mod notifications;
pub mod presence;
pub mod rate_limit;
pub mod audit;
pub mod room_sessions;
pub mod routes;
pub mod ws;

use axum::http::{header, HeaderValue, Method};
use axum::Router;
use sqlx::migrate::Migrator;
use tower_http::cors::{AllowOrigin, CorsLayer};
use tower_http::trace::TraceLayer;

use crate::config::Config;
use crate::db::AppState;
use crate::ws::WsHub;

pub static MIGRATOR: Migrator = sqlx::migrate!("./migrations");

/// Build the HTTP application router with standard middleware.
pub fn build_app(state: AppState) -> Router {
    let cors = build_cors_layer(&state.config);
    Router::new()
        .merge(routes::router())
        .layer(cors)
        .layer(TraceLayer::new_for_http())
        .with_state(state)
}

fn build_cors_layer(config: &Config) -> CorsLayer {
    let origins: Vec<HeaderValue> = config
        .cors_origins
        .iter()
        .filter_map(|origin| origin.parse::<HeaderValue>().ok())
        .collect();

    CorsLayer::new()
        .allow_origin(AllowOrigin::list(origins))
        .allow_methods([
            Method::GET,
            Method::POST,
            Method::PUT,
            Method::PATCH,
            Method::DELETE,
            Method::OPTIONS,
        ])
        .allow_headers([
            header::AUTHORIZATION,
            header::CONTENT_TYPE,
            header::ACCEPT,
        ])
}

/// Connect to Postgres + Redis, run migrations, sync achievement catalog.
pub async fn build_state(config: Config) -> Result<AppState, Box<dyn std::error::Error>> {
    let pool = db::connect(&config.database_url).await?;
    MIGRATOR.run(&pool).await?;
    achievements::sync_catalog(&pool).await?;
    let redis = db::connect_redis(&config.redis_url).await?;
    let ws = WsHub::new();
    Ok(AppState {
        pool,
        redis,
        config,
        ws,
    })
}
