use std::time::Duration;

const WEAK_SECRETS: &[&str] = &[
    "change-me-in-production",
    "change-me-turn-secret",
    "dev-jwt-secret-change-me",
    "secret",
    "jwt_secret",
    "turn_secret",
    "password",
];

#[derive(Clone, Debug)]
pub struct Config {
    pub listen_addr: String,
    pub database_url: String,
    pub redis_url: String,
    pub jwt_secret: String,
    pub jwt_access_ttl: Duration,
    pub jwt_refresh_ttl: Duration,
    pub jwt_issuer: String,
    pub jwt_audience: String,
    /// Seconds without heartbeat before a user is considered offline.
    pub presence_timeout_secs: u64,
    /// Host/IP for TURN (coturn). Empty disables TURN credentials.
    pub turn_host: String,
    pub turn_secret: String,
    pub turn_realm: String,
    pub turn_ttl_secs: u64,
    /// Comma-separated STUN urls, e.g. stun:stun.l.google.com:19302
    pub stun_urls: Vec<String>,
    /// Allowed browser/Tauri origins for CORS (exact match).
    pub cors_origins: Vec<String>,
    /// When true, `/identities/link` requires a live provider access token.
    pub require_identity_proof: bool,
}

impl Config {
    pub fn from_env() -> Result<Self, String> {
        let turn_host = std::env::var("TURN_HOST").unwrap_or_default();
        let turn_secret = if turn_host.trim().is_empty() {
            std::env::var("TURN_SECRET").unwrap_or_default()
        } else {
            require_strong_secret("TURN_SECRET", 16)?
        };

        Ok(Self {
            listen_addr: std::env::var("API_LISTEN_ADDR")
                .unwrap_or_else(|_| "0.0.0.0:8080".into()),
            database_url: require_env("DATABASE_URL")?,
            redis_url: std::env::var("REDIS_URL")
                .unwrap_or_else(|_| "redis://127.0.0.1:6379".into()),
            jwt_secret: require_strong_secret("JWT_SECRET", 32)?,
            jwt_access_ttl: Duration::from_secs(
                std::env::var("JWT_ACCESS_TTL_SECS")
                    .ok()
                    .and_then(|v| v.parse().ok())
                    .unwrap_or(900),
            ),
            jwt_refresh_ttl: Duration::from_secs(
                std::env::var("JWT_REFRESH_TTL_SECS")
                    .ok()
                    .and_then(|v| v.parse().ok())
                    .unwrap_or(2_592_000), //30 days
            ),
            jwt_issuer: std::env::var("JWT_ISSUER")
                .unwrap_or_else(|_| "mc16launcher-api".into()),
            jwt_audience: std::env::var("JWT_AUDIENCE")
                .unwrap_or_else(|_| "mc16launcher".into()),
            presence_timeout_secs: std::env::var("PRESENCE_TIMEOUT_SECS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(60),
            turn_host,
            turn_secret,
            turn_realm: std::env::var("TURN_REALM").unwrap_or_else(|_| "16launcher.local".into()),
            turn_ttl_secs: std::env::var("TURN_TTL_SECS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(600),
            stun_urls: parse_stun_urls(),
            cors_origins: parse_cors_origins(),
            require_identity_proof: parse_bool_env("IDENTITY_REQUIRE_PROOF", true),
        })
    }

    /// Config for integration tests. Prefers `TEST_DATABASE_URL` / `TEST_REDIS_URL`.
    pub fn for_tests() -> Self {
        let database_url = std::env::var("TEST_DATABASE_URL")
            .or_else(|_| std::env::var("DATABASE_URL"))
            .unwrap_or_else(|_| "postgres://launcher:launcher@127.0.0.1:5432/launcher".into());
        let redis_url = std::env::var("TEST_REDIS_URL")
            .or_else(|_| std::env::var("REDIS_URL"))
            .unwrap_or_else(|_| "redis://127.0.0.1:6379".into());
        let jwt_secret = std::env::var("JWT_SECRET")
            .unwrap_or_else(|_| "test-jwt-secret-not-for-production-32b".into());

        Self {
            listen_addr: "127.0.0.1:0".into(),
            database_url,
            redis_url,
            jwt_secret,
            jwt_access_ttl: Duration::from_secs(900),
            jwt_refresh_ttl: Duration::from_secs(2_592_000),
            jwt_issuer: "mc16launcher-api".into(),
            jwt_audience: "mc16launcher".into(),
            presence_timeout_secs: 60,
            turn_host: "127.0.0.1".into(),
            turn_secret: "test-turn-secret-not-default".into(),
            turn_realm: "16launcher.test".into(),
            turn_ttl_secs: 600,
            stun_urls: parse_stun_urls(),
            cors_origins: default_cors_origins(),
            // Integration tests link without live Ely/Microsoft tokens.
            require_identity_proof: false,
        }
    }
}

fn parse_stun_urls() -> Vec<String> {
    std::env::var("STUN_URLS")
        .unwrap_or_else(|_| {
            "stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302".into()
        })
        .split(',')
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(str::to_string)
        .collect()
}

fn default_cors_origins() -> Vec<String> {
    vec![
        "http://localhost:1420".into(),
        "http://127.0.0.1:1420".into(),
        "http://localhost:5173".into(),
        "http://127.0.0.1:5173".into(),
        "tauri://localhost".into(),
        "https://tauri.localhost".into(),
    ]
}

fn parse_cors_origins() -> Vec<String> {
    match std::env::var("CORS_ORIGINS") {
        Ok(raw) if !raw.trim().is_empty() => raw
            .split(',')
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .map(str::to_string)
            .collect(),
        _ => default_cors_origins(),
    }
}

fn parse_bool_env(key: &str, default: bool) -> bool {
    std::env::var(key)
        .ok()
        .map(|v| matches!(v.trim().to_ascii_lowercase().as_str(), "1" | "true" | "yes" | "on"))
        .unwrap_or(default)
}

fn require_env(key: &str) -> Result<String, String> {
    std::env::var(key).map_err(|_| format!("missing required env var: {key}"))
}

fn require_strong_secret(key: &str, min_len: usize) -> Result<String, String> {
    let value = require_env(key)?;
    if value.len() < min_len {
        return Err(format!("{key} must be at least {min_len} characters"));
    }
    if WEAK_SECRETS
        .iter()
        .any(|weak| value.eq_ignore_ascii_case(weak))
    {
        return Err(format!(
            "{key} uses a known insecure default; set a unique strong secret"
        ));
    }
    Ok(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_weak_jwt_defaults() {
        assert!(require_strong_secret_value("change-me-in-production", 32).is_err());
        assert!(require_strong_secret_value("short", 32).is_err());
        assert!(require_strong_secret_value(&"a".repeat(32), 32).is_ok());
    }

    fn require_strong_secret_value(value: &str, min_len: usize) -> Result<(), String> {
        if value.len() < min_len {
            return Err("too short".into());
        }
        if WEAK_SECRETS
            .iter()
            .any(|weak| value.eq_ignore_ascii_case(weak))
        {
            return Err("weak".into());
        }
        Ok(())
    }
}
