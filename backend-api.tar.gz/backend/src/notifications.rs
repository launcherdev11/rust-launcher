use serde_json::{json, Value};
use sqlx::Row;
use uuid::Uuid;

use crate::db::AppState;
use crate::error::ApiError;
use crate::ws::WsEvent;

pub const TYPE_FRIEND_REQUEST: &str = "friend_request";
pub const TYPE_FRIEND_ACCEPT: &str = "friend_accept";
pub const TYPE_ROOM_INVITE: &str = "room_invite";
#[allow(dead_code)]
pub const TYPE_ACHIEVEMENT: &str = "achievement";
#[allow(dead_code)]
pub const TYPE_SYSTEM: &str = "system";

#[derive(Debug, Clone, serde::Serialize)]
pub struct NotificationRow {
    pub id: String,
    pub user_id: String,
    #[serde(rename = "type")]
    pub notification_type: String,
    pub payload: Value,
    pub created_at: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub read_at: Option<String>,
}

pub async fn create_notification(
    state: &AppState,
    user_id: Uuid,
    notification_type: &str,
    payload: Value,
) -> Result<NotificationRow, ApiError> {
    let row = sqlx::query(
        r#"
        INSERT INTO notifications (user_id, type, payload)
        VALUES ($1, $2, $3)
        RETURNING id, user_id, type, payload, created_at, read_at
        "#,
    )
    .bind(user_id)
    .bind(notification_type)
    .bind(payload)
    .fetch_one(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    let notification = map_row(&row);
    state
        .ws
        .send_to_user(
            user_id,
            WsEvent::Notification {
                id: notification.id.clone(),
                notification_type: notification.notification_type.clone(),
                payload: notification.payload.clone(),
            },
        )
        .await;

    Ok(notification)
}

pub async fn list_for_user(
    state: &AppState,
    user_id: Uuid,
    limit: i64,
) -> Result<Vec<NotificationRow>, ApiError> {
    let rows = sqlx::query(
        r#"
        SELECT id, user_id, type, payload, created_at, read_at
        FROM notifications
        WHERE user_id = $1
        ORDER BY created_at DESC
        LIMIT $2
        "#,
    )
    .bind(user_id)
    .bind(limit.clamp(1, 100))
    .fetch_all(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(rows.iter().map(map_row).collect())
}

pub async fn mark_read(
    state: &AppState,
    user_id: Uuid,
    notification_id: Uuid,
) -> Result<(), ApiError> {
    let result = sqlx::query(
        r#"
        UPDATE notifications
        SET read_at = COALESCE(read_at, now())
        WHERE id = $1 AND user_id = $2
        "#,
    )
    .bind(notification_id)
    .bind(user_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    if result.rows_affected() == 0 {
        return Err(ApiError::NotFound);
    }
    Ok(())
}

pub async fn mark_all_read(state: &AppState, user_id: Uuid) -> Result<u64, ApiError> {
    let result = sqlx::query(
        r#"
        UPDATE notifications
        SET read_at = now()
        WHERE user_id = $1 AND read_at IS NULL
        "#,
    )
    .bind(user_id)
    .execute(&state.pool)
    .await
    .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(result.rows_affected())
}

fn map_row(row: &sqlx::postgres::PgRow) -> NotificationRow {
    NotificationRow {
        id: row.get::<Uuid, _>("id").to_string(),
        user_id: row.get::<Uuid, _>("user_id").to_string(),
        notification_type: row.get("type"),
        payload: row.get::<Value, _>("payload"),
        created_at: row
            .get::<chrono::DateTime<chrono::Utc>, _>("created_at")
            .to_rfc3339(),
        read_at: row
            .get::<Option<chrono::DateTime<chrono::Utc>>, _>("read_at")
            .map(|dt| dt.to_rfc3339()),
    }
}

pub fn friend_request_payload(
    request_id: Uuid,
    from_user_id: Uuid,
    from_nickname: &str,
) -> Value {
    json!({
        "request_id": request_id.to_string(),
        "from_user_id": from_user_id.to_string(),
        "from_nickname": from_nickname,
    })
}

pub fn friend_accept_payload(friend_user_id: Uuid, friend_nickname: &str) -> Value {
    json!({
        "friend_user_id": friend_user_id.to_string(),
        "friend_nickname": friend_nickname,
    })
}

pub fn room_invite_payload(
    room_id: Uuid,
    from_user_id: Uuid,
    from_nickname: &str,
) -> Value {
    json!({
        "room_id": room_id.to_string(),
        "from_user_id": from_user_id.to_string(),
        "from_nickname": from_nickname,
    })
}
