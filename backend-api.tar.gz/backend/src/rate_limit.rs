//! Redis-backed fixed-window rate limiting.

use redis::AsyncCommands;

use crate::db::AppState;
use crate::error::ApiError;

#[derive(Clone, Copy)]
pub struct RateLimit {
    pub key_prefix: &'static str,
    pub limit: u64,
    pub window_secs: u64,
}

pub const LOGIN: RateLimit = RateLimit {
    key_prefix: "rl:login",
    limit: 20,
    window_secs: 60,
};

pub const REGISTER: RateLimit = RateLimit {
    key_prefix: "rl:register",
    limit: 10,
    window_secs: 60,
};

pub const REGISTER_EMAIL: RateLimit = RateLimit {
    key_prefix: "rl:register_email",
    limit: 5,
    window_secs: 3600,
};

pub const REFRESH: RateLimit = RateLimit {
    key_prefix: "rl:refresh",
    limit: 30,
    window_secs: 60,
};

pub const FRIEND_REQUEST: RateLimit = RateLimit {
    key_prefix: "rl:friend_req",
    limit: 30,
    window_secs: 60,
};

pub const ROOM_CREATE: RateLimit = RateLimit {
    key_prefix: "rl:room_create",
    limit: 20,
    window_secs: 60,
};

pub const ROOM_INVITE: RateLimit = RateLimit {
    key_prefix: "rl:room_invite",
    limit: 40,
    window_secs: 60,
};

pub const TURN: RateLimit = RateLimit {
    key_prefix: "rl:turn",
    limit: 30,
    window_secs: 60,
};

pub const WS_MESSAGE: RateLimit = RateLimit {
    key_prefix: "rl:ws",
    limit: 120,
    window_secs: 60,
};

/// Returns Ok(()) if under limit, Err(BadRequest) when exceeded.
pub async fn check(state: &AppState, limit: RateLimit, subject: &str) -> Result<(), ApiError> {
    let key = format!("{}:{}", limit.key_prefix, subject);
    let mut redis = state.redis.clone();

    let count: u64 = redis
        .incr(&key, 1u64)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    if count == 1 {
        let _: () = redis
            .expire(&key, limit.window_secs as i64)
            .await
            .map_err(|e| ApiError::Internal(e.to_string()))?;
    }

    if count > limit.limit {
        return Err(ApiError::bad_request("rate limit exceeded"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn presets_have_positive_limits() {
        assert!(LOGIN.limit > 0);
        assert!(REGISTER.limit > 0);
        assert!(REGISTER_EMAIL.window_secs >= 60);
        assert!(TURN.window_secs > 0);
        assert!(WS_MESSAGE.limit >= 60);
    }
}
