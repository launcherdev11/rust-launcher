use std::time::Duration;

use axum::{
    extract::{
        ws::{Message, WebSocket, WebSocketUpgrade},
        Query, State,
    },
    response::IntoResponse,
    routing::get,
    Router,
};
use futures_util::{SinkExt, StreamExt};
use serde::Deserialize;
use sqlx::Row;
use uuid::Uuid;

use crate::auth::{decode_access_token, AccessClaims};
use crate::db::AppState;
use crate::presence;
use crate::room_sessions;
use crate::ws::events::{WsClientMessage, WsEvent};
use crate::ws::signaling::{
    self, broadcast_to_room, can_signal_peer, is_active_room_member, parse_room_id, sdp_ok,
    MAX_WS_TEXT_BYTES, WS_HEARTBEAT_TIMEOUT_SECS,
};

#[derive(Deserialize)]
pub struct WsQuery {
    /// Access JWT (preferred for browser/Tauri WebSocket).
    pub token: Option<String>,
}

pub fn router() -> Router<AppState> {
    Router::new().route("/ws", get(ws_upgrade))
}

async fn ws_upgrade(
    ws: WebSocketUpgrade,
    State(state): State<AppState>,
    Query(query): Query<WsQuery>,
    headers: axum::http::HeaderMap,
) -> impl IntoResponse {
    match resolve_token_and_user(&state, &query, &headers) {
        Ok((token, user_id)) => {
            ws.on_upgrade(move |socket| handle_socket(socket, state, user_id, token))
        }
        Err(msg) => {
            tracing::warn!("ws auth failed");
            (axum::http::StatusCode::UNAUTHORIZED, msg).into_response()
        }
    }
}

fn resolve_token_and_user(
    state: &AppState,
    query: &WsQuery,
    headers: &axum::http::HeaderMap,
) -> Result<(String, Uuid), String> {
    let token = query
        .token
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .or_else(|| {
            headers
                .get(axum::http::header::AUTHORIZATION)
                .and_then(|v| v.to_str().ok())
                .and_then(|v| v.strip_prefix("Bearer "))
        })
        .ok_or_else(|| "missing token".to_string())?
        .to_string();

    let data = jsonwebtoken::decode::<AccessClaims>(
        &token,
        &jsonwebtoken::DecodingKey::from_secret(state.config.jwt_secret.as_bytes()),
        &{
            let mut v = jsonwebtoken::Validation::default();
            v.set_issuer(&[state.config.jwt_issuer.clone()]);
            v.set_audience(&[state.config.jwt_audience.clone()]);
            v
        },
    )
    .map_err(|_| "invalid token".to_string())?;

    if data.claims.typ != "access" {
        return Err("invalid token type".into());
    }

    let user_id = Uuid::parse_str(&data.claims.sub).map_err(|_| "invalid subject".to_string())?;
    Ok((token, user_id))
}

async fn friend_ids(state: &AppState, user_id: Uuid) -> Vec<Uuid> {
    match sqlx::query("SELECT friend_user_id FROM friends WHERE user_id = $1")
        .bind(user_id)
        .fetch_all(&state.pool)
        .await
    {
        Ok(rows) => rows
            .into_iter()
            .map(|row| row.get::<Uuid, _>("friend_user_id"))
            .collect(),
        Err(e) => {
            tracing::warn!("ws friend lookup failed: {e}");
            Vec::new()
        }
    }
}

async fn nickname_of(state: &AppState, user_id: Uuid) -> Option<String> {
    sqlx::query_scalar::<_, String>("SELECT nickname FROM users WHERE id = $1")
        .bind(user_id)
        .fetch_optional(&state.pool)
        .await
        .ok()
        .flatten()
}

async fn notify_friends_online(state: &AppState, user_id: Uuid) {
    let nickname = nickname_of(state, user_id).await;
    let friends = friend_ids(state, user_id).await;
    state
        .ws
        .send_to_users(
            friends,
            WsEvent::UserOnline {
                user_id: user_id.to_string(),
                nickname,
            },
        )
        .await;
}

async fn notify_friends_offline(state: &AppState, user_id: Uuid, last_seen: Option<String>) {
    let friends = friend_ids(state, user_id).await;
    state
        .ws
        .send_to_users(
            friends,
            WsEvent::UserOffline {
                user_id: user_id.to_string(),
                last_seen,
            },
        )
        .await;
}

async fn handle_signaling(
    state: &AppState,
    user_id: Uuid,
    msg: WsClientMessage,
) {
    match msg {
        WsClientMessage::Offer {
            to_user_id,
            room_id,
            sdp,
        } => {
            if !sdp_ok(&sdp) {
                return;
            }
            let Some(room) = parse_room_id(&room_id) else {
                return;
            };
            let Ok(target) = Uuid::parse_str(&to_user_id) else {
                return;
            };
            match can_signal_peer(state, room, user_id, target).await {
                Ok(true) => {
                    state
                        .ws
                        .send_to_user(
                            target,
                            WsEvent::Offer {
                                from_user_id: user_id.to_string(),
                                to_user_id,
                                room_id,
                                sdp,
                            },
                        )
                        .await;
                }
                Ok(false) => tracing::debug!("offer denied: room acl"),
                Err(e) => tracing::warn!("offer acl check failed: {e}"),
            }
        }
        WsClientMessage::Answer {
            to_user_id,
            room_id,
            sdp,
        } => {
            if !sdp_ok(&sdp) {
                return;
            }
            let Some(room) = parse_room_id(&room_id) else {
                return;
            };
            let Ok(target) = Uuid::parse_str(&to_user_id) else {
                return;
            };
            match can_signal_peer(state, room, user_id, target).await {
                Ok(true) => {
                    state
                        .ws
                        .send_to_user(
                            target,
                            WsEvent::Answer {
                                from_user_id: user_id.to_string(),
                                to_user_id,
                                room_id,
                                sdp,
                            },
                        )
                        .await;
                }
                Ok(false) => tracing::debug!("answer denied: room acl"),
                Err(e) => tracing::warn!("answer acl check failed: {e}"),
            }
        }
        WsClientMessage::IceCandidate {
            to_user_id,
            room_id,
            candidate,
        } => {
            if candidate.candidate.is_empty() || candidate.candidate.len() > 4096 {
                return;
            }
            let Some(room) = parse_room_id(&room_id) else {
                return;
            };
            let Ok(target) = Uuid::parse_str(&to_user_id) else {
                return;
            };
            match can_signal_peer(state, room, user_id, target).await {
                Ok(true) => {
                    state
                        .ws
                        .send_to_user(
                            target,
                            WsEvent::IceCandidate {
                                from_user_id: user_id.to_string(),
                                to_user_id,
                                room_id,
                                candidate,
                            },
                        )
                        .await;
                }
                Ok(false) => tracing::debug!("ice denied: room acl"),
                Err(e) => tracing::warn!("ice acl check failed: {e}"),
            }
        }
        WsClientMessage::PeerReady { room_id } => {
            let Some(room) = parse_room_id(&room_id) else {
                return;
            };
            match is_active_room_member(state, room, user_id).await {
                Ok(true) => {
                    // Ensure session exists; host is room owner.
                    if let Ok(Some(owner)) = sqlx::query_scalar::<_, Uuid>(
                        "SELECT owner_user_id FROM rooms WHERE id = $1",
                    )
                    .bind(room)
                    .fetch_optional(&state.pool)
                    .await
                    {
                        let _ = room_sessions::ensure_waiting_session(state, room, owner).await;
                        let _ = room_sessions::set_connecting(state, room).await;
                    }

                    let nickname = nickname_of(state, user_id).await;
                    broadcast_to_room(
                        state,
                        room,
                        WsEvent::PeerJoin {
                            room_id: room_id.clone(),
                            user_id: user_id.to_string(),
                            nickname,
                        },
                        Some(user_id),
                    )
                    .await;
                    broadcast_to_room(
                        state,
                        room,
                        WsEvent::PeerReady {
                            room_id,
                            user_id: user_id.to_string(),
                        },
                        None,
                    )
                    .await;
                }
                Ok(false) => tracing::debug!("peer_ready denied: not a member"),
                Err(e) => tracing::warn!("peer_ready acl failed: {e}"),
            }
        }
        WsClientMessage::ConnectionFailed { room_id, reason } => {
            let Some(room) = parse_room_id(&room_id) else {
                return;
            };
            match is_active_room_member(state, room, user_id).await {
                Ok(true) => {
                    let _ = room_sessions::mark_failed(state, room).await;
                    broadcast_to_room(
                        state,
                        room,
                        WsEvent::ConnectionFailed {
                            room_id,
                            user_id: user_id.to_string(),
                            reason,
                        },
                        None,
                    )
                    .await;
                }
                Ok(false) => {}
                Err(e) => tracing::warn!("connection_failed acl: {e}"),
            }
        }
        WsClientMessage::ConnectionEstablished {
            room_id,
            connection_type,
        } => {
            let Some(room) = parse_room_id(&room_id) else {
                return;
            };
            match is_active_room_member(state, room, user_id).await {
                Ok(true) => {
                    let _ = room_sessions::mark_connected(state, room, connection_type.clone()).await;
                    broadcast_to_room(
                        state,
                        room,
                        WsEvent::ConnectionEstablished {
                            room_id,
                            user_id: user_id.to_string(),
                            connection_type,
                        },
                        None,
                    )
                    .await;
                }
                Ok(false) => {}
                Err(e) => tracing::warn!("connection_established acl: {e}"),
            }
        }
        WsClientMessage::Heartbeat {} | WsClientMessage::PresenceHeartbeat {} => {
            // handled in the socket loop
        }
    }
}

async fn handle_socket(socket: WebSocket, state: AppState, user_id: Uuid, access_token: String) {
    if decode_access_token(&state, &access_token).await.is_err() {
        return;
    }

    let (mut sink, mut stream) = socket.split();
    let mut outbound = state.ws.subscribe(user_id).await;
    let mut last_client_activity = tokio::time::Instant::now();
    let mut heartbeat_tick =
        tokio::time::interval(Duration::from_secs(WS_HEARTBEAT_TIMEOUT_SECS / 3));

    if let Err(e) = presence::heartbeat(&state, user_id).await {
        tracing::warn!("ws presence heartbeat failed for {user_id}: {e}");
    }
    notify_friends_online(&state, user_id).await;

    if let Ok(text) = serde_json::to_string(&WsEvent::Heartbeat {}) {
        let _ = sink.send(Message::Text(text.into())).await;
    }

    loop {
        tokio::select! {
            incoming = stream.next() => {
                match incoming {
                    Some(Ok(Message::Text(text))) => {
                        if text.len() > MAX_WS_TEXT_BYTES {
                            tracing::debug!("ws message too large from {user_id}");
                            break;
                        }
                        last_client_activity = tokio::time::Instant::now();
                        if crate::rate_limit::check(
                            &state,
                            crate::rate_limit::WS_MESSAGE,
                            &user_id.to_string(),
                        )
                        .await
                        .is_err()
                        {
                            tracing::debug!("ws rate limited {user_id}");
                            continue;
                        }
                        match serde_json::from_str::<WsClientMessage>(&text) {
                            Ok(WsClientMessage::Heartbeat {})
                            | Ok(WsClientMessage::PresenceHeartbeat {}) => {
                                if let Err(e) = presence::heartbeat(&state, user_id).await {
                                    tracing::warn!("ws presence refresh failed: {e}");
                                }
                                if let Ok(reply) = serde_json::to_string(&WsEvent::Heartbeat {}) {
                                    if sink.send(Message::Text(reply.into())).await.is_err() {
                                        break;
                                    }
                                }
                            }
                            Ok(msg) => {
                                handle_signaling(&state, user_id, msg).await;
                            }
                            Err(e) => {
                                tracing::debug!("ws client message ignored: {e}");
                            }
                        }
                    }
                    Some(Ok(Message::Ping(payload))) => {
                        last_client_activity = tokio::time::Instant::now();
                        if sink.send(Message::Pong(payload)).await.is_err() {
                            break;
                        }
                    }
                    Some(Ok(Message::Close(_))) | None => break,
                    Some(Ok(_)) => {}
                    Some(Err(e)) => {
                        tracing::debug!("ws read error: {e}");
                        break;
                    }
                }
            }
            event = outbound.recv() => {
                match event {
                    Some(event) => {
                        match serde_json::to_string(&event) {
                            Ok(text) => {
                                if sink.send(Message::Text(text.into())).await.is_err() {
                                    break;
                                }
                            }
                            Err(e) => tracing::warn!("ws serialize failed: {e}"),
                        }
                    }
                    None => break,
                }
            }
            _ = heartbeat_tick.tick() => {
                if last_client_activity.elapsed()
                    > Duration::from_secs(WS_HEARTBEAT_TIMEOUT_SECS)
                {
                    tracing::debug!("ws heartbeat timeout for {user_id}");
                    break;
                }
            }
        }
    }

    if let Ok(rooms) = signaling::room_member_ids_for_user(&state, user_id).await {
        for room_id in rooms {
            broadcast_to_room(
                &state,
                room_id,
                WsEvent::PeerLeave {
                    room_id: room_id.to_string(),
                    user_id: user_id.to_string(),
                },
                Some(user_id),
            )
            .await;
            let _ = room_sessions::close_if_room_empty_or_closed(&state, room_id).await;
        }
    }

    state.ws.unsubscribe_dead(user_id).await;

    if !state.ws.is_connected(user_id).await {
        let last_seen = match presence::set_offline(&state, user_id).await {
            Ok(p) => p.last_seen,
            Err(e) => {
                tracing::warn!("ws presence offline failed for {user_id}: {e}");
                None
            }
        };
        notify_friends_offline(&state, user_id, last_seen).await;
    }
}
