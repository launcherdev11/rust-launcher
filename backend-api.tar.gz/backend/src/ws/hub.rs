use std::collections::HashMap;
use std::sync::Arc;

use tokio::sync::{mpsc, Mutex};
use uuid::Uuid;

use super::events::WsEvent;

type ConnTx = mpsc::UnboundedSender<WsEvent>;

#[derive(Clone, Default)]
pub struct WsHub {
    inner: Arc<Mutex<HashMap<Uuid, Vec<ConnTx>>>>,
}

impl WsHub {
    pub fn new() -> Self {
        Self::default()
    }

    pub async fn subscribe(&self, user_id: Uuid) -> mpsc::UnboundedReceiver<WsEvent> {
        let (tx, rx) = mpsc::unbounded_channel();
        let mut guard = self.inner.lock().await;
        guard.entry(user_id).or_default().push(tx);
        rx
    }

    pub async fn unsubscribe_dead(&self, user_id: Uuid) {
        let mut guard = self.inner.lock().await;
        if let Some(list) = guard.get_mut(&user_id) {
            list.retain(|tx| !tx.is_closed());
            if list.is_empty() {
                guard.remove(&user_id);
            }
        }
    }

    pub async fn send_to_user(&self, user_id: Uuid, event: WsEvent) {
        let mut guard = self.inner.lock().await;
        if let Some(list) = guard.get_mut(&user_id) {
            list.retain(|tx| tx.send(event.clone()).is_ok());
            if list.is_empty() {
                guard.remove(&user_id);
            }
        }
    }

    pub async fn send_to_users(&self, user_ids: impl IntoIterator<Item = Uuid>, event: WsEvent) {
        for user_id in user_ids {
            self.send_to_user(user_id, event.clone()).await;
        }
    }

    pub async fn is_connected(&self, user_id: Uuid) -> bool {
        let guard = self.inner.lock().await;
        guard
            .get(&user_id)
            .map(|list| list.iter().any(|tx| !tx.is_closed()))
            .unwrap_or(false)
    }
}
