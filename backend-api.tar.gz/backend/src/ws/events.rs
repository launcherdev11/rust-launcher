use serde::{Deserialize, Serialize};

/// Typed ICE candidate exchanged over WebSocket (no free-form JSON).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct IceCandidateDto {
    pub candidate: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sdp_mid: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sdp_m_line_index: Option<u16>,
}

/// Connection type reported after ICE succeeds.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ConnectionType {
    Direct,
    Relay,
}

/// Typed WebSocket envelope. Wire format:
/// `{ "type": "...", "payload": { ... } }`
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", content = "payload", rename_all = "snake_case")]
pub enum WsEvent {
    UserOnline {
        user_id: String,
        #[serde(skip_serializing_if = "Option::is_none")]
        nickname: Option<String>,
    },
    UserOffline {
        user_id: String,
        #[serde(skip_serializing_if = "Option::is_none")]
        last_seen: Option<String>,
    },
    FriendRequestCreated {
        request_id: String,
        from_user_id: String,
        from_nickname: String,
        to_user_id: String,
    },
    FriendRequestAccepted {
        request_id: String,
        user_id: String,
        friend_user_id: String,
    },
    FriendRemoved {
        user_id: String,
        friend_user_id: String,
    },
    RoomCreated {
        room_id: String,
        owner_user_id: String,
    },
    RoomUpdated {
        room_id: String,
        status: String,
        member_count: i32,
    },
    RoomClosed {
        room_id: String,
    },
    RoomMemberJoined {
        room_id: String,
        user_id: String,
        nickname: String,
    },
    RoomMemberLeft {
        room_id: String,
        user_id: String,
    },
    RoomInvite {
        room_id: String,
        from_user_id: String,
        from_nickname: String,
        to_user_id: String,
    },
    Notification {
        id: String,
        notification_type: String,
        payload: serde_json::Value,
    },
    /// WebRTC signaling — backend relays SDP without interpreting it.
    Offer {
        from_user_id: String,
        to_user_id: String,
        room_id: String,
        sdp: String,
    },
    Answer {
        from_user_id: String,
        to_user_id: String,
        room_id: String,
        sdp: String,
    },
    IceCandidate {
        from_user_id: String,
        to_user_id: String,
        room_id: String,
        candidate: IceCandidateDto,
    },
    PeerJoin {
        room_id: String,
        user_id: String,
        #[serde(skip_serializing_if = "Option::is_none")]
        nickname: Option<String>,
    },
    PeerLeave {
        room_id: String,
        user_id: String,
    },
    PeerReady {
        room_id: String,
        user_id: String,
    },
    ConnectionFailed {
        room_id: String,
        user_id: String,
        #[serde(skip_serializing_if = "Option::is_none")]
        reason: Option<String>,
    },
    ConnectionEstablished {
        room_id: String,
        user_id: String,
        connection_type: ConnectionType,
    },
    Heartbeat {},
}

/// Client → server messages.
#[derive(Debug, Deserialize)]
#[serde(tag = "type", content = "payload", rename_all = "snake_case")]
pub enum WsClientMessage {
    Heartbeat {},
    /// Explicit presence refresh over the socket.
    PresenceHeartbeat {},
    Offer {
        to_user_id: String,
        room_id: String,
        sdp: String,
    },
    Answer {
        to_user_id: String,
        room_id: String,
        sdp: String,
    },
    IceCandidate {
        to_user_id: String,
        room_id: String,
        candidate: IceCandidateDto,
    },
    PeerReady {
        room_id: String,
    },
    ConnectionFailed {
        room_id: String,
        #[serde(default)]
        reason: Option<String>,
    },
    ConnectionEstablished {
        room_id: String,
        connection_type: ConnectionType,
    },
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn server_event_roundtrip_friend_request() {
        let event = WsEvent::FriendRequestCreated {
            request_id: "r1".into(),
            from_user_id: "u1".into(),
            from_nickname: "alice".into(),
            to_user_id: "u2".into(),
        };
        let raw = serde_json::to_value(&event).unwrap();
        assert_eq!(raw["type"], "friend_request_created");
        let back: WsEvent = serde_json::from_value(raw).unwrap();
        match back {
            WsEvent::FriendRequestCreated { from_nickname, .. } => {
                assert_eq!(from_nickname, "alice")
            }
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn server_event_heartbeat_wire_shape() {
        let raw = serde_json::to_value(WsEvent::Heartbeat {}).unwrap();
        assert_eq!(raw["type"], "heartbeat");
        assert!(raw.get("payload").is_some());
    }

    #[test]
    fn client_message_offer_requires_room_id() {
        let msg: WsClientMessage = serde_json::from_value(json!({
            "type": "offer",
            "payload": {
                "to_user_id": "peer",
                "room_id": "room-1",
                "sdp": "v=0"
            }
        }))
        .unwrap();
        match msg {
            WsClientMessage::Offer {
                to_user_id,
                sdp,
                room_id,
            } => {
                assert_eq!(to_user_id, "peer");
                assert_eq!(sdp, "v=0");
                assert_eq!(room_id, "room-1");
            }
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn ice_candidate_dto_roundtrip() {
        let event = WsEvent::IceCandidate {
            from_user_id: "a".into(),
            to_user_id: "b".into(),
            room_id: "r".into(),
            candidate: IceCandidateDto {
                candidate: "candidate:1 1 UDP 1 1.2.3.4 1234 typ host".into(),
                sdp_mid: Some("0".into()),
                sdp_m_line_index: Some(0),
            },
        };
        let raw = serde_json::to_value(&event).unwrap();
        assert_eq!(raw["type"], "ice_candidate");
        assert_eq!(raw["payload"]["candidate"]["sdp_m_line_index"], 0);
        let back: WsEvent = serde_json::from_value(raw).unwrap();
        match back {
            WsEvent::IceCandidate { candidate, .. } => {
                assert_eq!(candidate.sdp_mid.as_deref(), Some("0"));
            }
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn peer_ready_and_connection_events_roundtrip() {
        let ready = WsEvent::PeerReady {
            room_id: "r1".into(),
            user_id: "u1".into(),
        };
        let established = WsEvent::ConnectionEstablished {
            room_id: "r1".into(),
            user_id: "u1".into(),
            connection_type: ConnectionType::Direct,
        };
        assert_eq!(serde_json::to_value(&ready).unwrap()["type"], "peer_ready");
        assert_eq!(
            serde_json::to_value(&established).unwrap()["payload"]["connection_type"],
            "direct"
        );
    }

    #[test]
    fn notification_event_keeps_payload() {
        let event = WsEvent::Notification {
            id: "n1".into(),
            notification_type: "friend_request".into(),
            payload: json!({ "from": "bob" }),
        };
        let raw = serde_json::to_value(&event).unwrap();
        assert_eq!(raw["type"], "notification");
        assert_eq!(raw["payload"]["payload"]["from"], "bob");
    }
}
