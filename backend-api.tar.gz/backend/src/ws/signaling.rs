use sqlx::Row;
use uuid::Uuid;

use crate::db::AppState;
use crate::ws::events::WsEvent;

/// Max WebSocket text frame size (64 KiB).
pub const MAX_WS_TEXT_BYTES: usize = 64 * 1024;

/// Close the socket if no client message / heartbeat within this window.
pub const WS_HEARTBEAT_TIMEOUT_SECS: u64 = 90;

/// Max SDP length we will relay (still opaque — we only enforce size).
pub const MAX_SDP_CHARS: usize = 32 * 1024;

/// Returns true when `user_id` is a member of a non-closed room.
pub async fn is_active_room_member(
    state: &AppState,
    room_id: Uuid,
    user_id: Uuid,
) -> Result<bool, sqlx::Error> {
    let row = sqlx::query(
        r#"
        SELECT 1 AS ok
        FROM room_members rm
        INNER JOIN rooms r ON r.id = rm.room_id
        WHERE rm.room_id = $1
          AND rm.user_id = $2
          AND r.status <> 'closed'
        "#,
    )
    .bind(room_id)
    .bind(user_id)
    .fetch_optional(&state.pool)
    .await?;
    Ok(row.is_some())
}

/// Both peers must be members of the same non-closed room.
pub async fn can_signal_peer(
    state: &AppState,
    room_id: Uuid,
    from_user_id: Uuid,
    to_user_id: Uuid,
) -> Result<bool, sqlx::Error> {
    if from_user_id == to_user_id {
        return Ok(false);
    }
    let from_ok = is_active_room_member(state, room_id, from_user_id).await?;
    if !from_ok {
        return Ok(false);
    }
    is_active_room_member(state, room_id, to_user_id).await
}

pub async fn room_member_ids(
    state: &AppState,
    room_id: Uuid,
) -> Result<Vec<Uuid>, sqlx::Error> {
    let rows = sqlx::query(
        r#"
        SELECT rm.user_id
        FROM room_members rm
        INNER JOIN rooms r ON r.id = rm.room_id
        WHERE rm.room_id = $1 AND r.status <> 'closed'
        "#,
    )
    .bind(room_id)
    .fetch_all(&state.pool)
    .await?;
    Ok(rows
        .into_iter()
        .map(|row| row.get::<Uuid, _>("user_id"))
        .collect())
}

/// Active (non-closed) rooms the user currently belongs to.
pub async fn room_member_ids_for_user(
    state: &AppState,
    user_id: Uuid,
) -> Result<Vec<Uuid>, sqlx::Error> {
    let rows = sqlx::query(
        r#"
        SELECT rm.room_id
        FROM room_members rm
        INNER JOIN rooms r ON r.id = rm.room_id
        WHERE rm.user_id = $1 AND r.status <> 'closed'
        "#,
    )
    .bind(user_id)
    .fetch_all(&state.pool)
    .await?;
    Ok(rows
        .into_iter()
        .map(|row| row.get::<Uuid, _>("room_id"))
        .collect())
}

pub async fn broadcast_to_room(
    state: &AppState,
    room_id: Uuid,
    event: WsEvent,
    except: Option<Uuid>,
) {
    match room_member_ids(state, room_id).await {
        Ok(members) => {
            let targets: Vec<Uuid> = members
                .into_iter()
                .filter(|id| except.map(|e| e != *id).unwrap_or(true))
                .collect();
            state.ws.send_to_users(targets, event).await;
        }
        Err(e) => tracing::warn!("room member lookup failed for {room_id}: {e}"),
    }
}

pub fn parse_room_id(room_id: &str) -> Option<Uuid> {
    Uuid::parse_str(room_id.trim()).ok()
}

pub fn sdp_ok(sdp: &str) -> bool {
    !sdp.is_empty() && sdp.len() <= MAX_SDP_CHARS
}
