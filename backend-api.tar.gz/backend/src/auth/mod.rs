use axum::http::HeaderMap;
use chrono::{Duration, Utc};
use jsonwebtoken::{decode, encode, DecodingKey, EncodingKey, Header, Validation};
use redis::AsyncCommands;
use sha2::{Digest, Sha256};
use uuid::Uuid;

use crate::config::Config;
use crate::db::AppState;
use crate::error::ApiError;

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct AccessClaims {
    pub sub: String,
    pub exp: i64,
    pub iat: i64,
    pub iss: String,
    pub aud: String,
    pub jti: String,
    pub typ: String,
}

pub fn hash_refresh_token(token: &str) -> String {
    let digest = Sha256::digest(token.as_bytes());
    digest.iter().map(|b| format!("{b:02x}")).collect()
}

fn access_validation(config: &Config) -> Validation {
    let mut validation = Validation::default();
    validation.set_issuer(&[config.jwt_issuer.clone()]);
    validation.set_audience(&[config.jwt_audience.clone()]);
    validation.validate_exp = true;
    validation
}

pub fn sign_access_token(config: &Config, user_id: Uuid) -> Result<String, ApiError> {
    let now = Utc::now();
    let exp = (now
        + Duration::from_std(config.jwt_access_ttl)
            .map_err(|e| ApiError::Internal(e.to_string()))?)
    .timestamp();

    let claims = AccessClaims {
        sub: user_id.to_string(),
        exp,
        iat: now.timestamp(),
        iss: config.jwt_issuer.clone(),
        aud: config.jwt_audience.clone(),
        jti: Uuid::new_v4().to_string(),
        typ: "access".into(),
    };

    encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(config.jwt_secret.as_bytes()),
    )
    .map_err(|e| ApiError::Internal(e.to_string()))
}

fn jti_denylist_key(jti: &str) -> String {
    format!("auth:jti:{jti}")
}

pub async fn revoke_access_jti(
    state: &AppState,
    jti: &str,
    remaining_ttl_secs: u64,
) -> Result<(), ApiError> {
    if remaining_ttl_secs == 0 || jti.is_empty() {
        return Ok(());
    }
    let mut redis = state.redis.clone();
    redis
        .set_ex::<_, _, ()>(jti_denylist_key(jti), "1", remaining_ttl_secs.max(1))
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(())
}

async fn is_jti_revoked(state: &AppState, jti: &str) -> Result<bool, ApiError> {
    let mut redis = state.redis.clone();
    let exists: bool = redis
        .exists(jti_denylist_key(jti))
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    Ok(exists)
}

/// Decode and validate an access JWT (signature, exp, iss, aud, typ, jti denylist).
pub async fn decode_access_token(
    state: &AppState,
    token: &str,
) -> Result<AccessClaims, ApiError> {
    let data = decode::<AccessClaims>(
        token,
        &DecodingKey::from_secret(state.config.jwt_secret.as_bytes()),
        &access_validation(&state.config),
    )
    .map_err(|_| ApiError::Unauthorized)?;

    if data.claims.typ != "access" {
        return Err(ApiError::Unauthorized);
    }

    if is_jti_revoked(state, &data.claims.jti).await? {
        return Err(ApiError::Unauthorized);
    }

    Ok(data.claims)
}

pub async fn extract_user_id(state: &AppState, headers: &HeaderMap) -> Result<Uuid, ApiError> {
    let auth = headers
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .ok_or(ApiError::Unauthorized)?;

    let token = auth
        .strip_prefix("Bearer ")
        .ok_or(ApiError::Unauthorized)?;

    let claims = decode_access_token(state, token).await?;
    Uuid::parse_str(&claims.sub).map_err(|_| ApiError::Unauthorized)
}

/// Extract full access claims (for logout jti revocation).
pub async fn extract_access_claims(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<AccessClaims, ApiError> {
    let auth = headers
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .ok_or(ApiError::Unauthorized)?;

    let token = auth
        .strip_prefix("Bearer ")
        .ok_or(ApiError::Unauthorized)?;

    decode_access_token(state, token).await
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    fn test_config() -> Config {
        Config {
            listen_addr: "127.0.0.1:0".into(),
            database_url: "postgres://unused".into(),
            redis_url: "redis://unused".into(),
            jwt_secret: "unit-test-secret".into(),
            jwt_access_ttl: Duration::from_secs(300),
            jwt_refresh_ttl: Duration::from_secs(3600),
            jwt_issuer: "mc16launcher-api".into(),
            jwt_audience: "mc16launcher".into(),
            presence_timeout_secs: 60,
            turn_host: String::new(),
            turn_secret: "x".into(),
            turn_realm: "test".into(),
            turn_ttl_secs: 60,
            stun_urls: vec![],
            cors_origins: vec!["http://localhost:1420".into()],
            require_identity_proof: true,
        }
    }

    #[test]
    fn refresh_token_hash_is_stable_hex() {
        let a = hash_refresh_token("token-abc");
        let b = hash_refresh_token("token-abc");
        assert_eq!(a, b);
        assert_eq!(a.len(), 64);
        assert!(a.chars().all(|c| c.is_ascii_hexdigit()));
        assert_ne!(hash_refresh_token("token-abc"), hash_refresh_token("token-xyz"));
    }

    #[test]
    fn sign_and_decode_access_claims() {
        let config = test_config();
        let user_id = Uuid::new_v4();
        let token = sign_access_token(&config, user_id).expect("sign");

        let data = decode::<AccessClaims>(
            &token,
            &DecodingKey::from_secret(config.jwt_secret.as_bytes()),
            &access_validation(&config),
        )
        .expect("decode");

        assert_eq!(data.claims.sub, user_id.to_string());
        assert_eq!(data.claims.typ, "access");
        assert_eq!(data.claims.iss, "mc16launcher-api");
        assert_eq!(data.claims.aud, "mc16launcher");
        assert!(!data.claims.jti.is_empty());
        assert!(data.claims.exp > Utc::now().timestamp());
    }

    #[test]
    fn wrong_audience_rejected() {
        let config = test_config();
        let token = sign_access_token(&config, Uuid::new_v4()).expect("sign");
        let mut bad = config.clone();
        bad.jwt_audience = "other".into();
        let err = decode::<AccessClaims>(
            &token,
            &DecodingKey::from_secret(bad.jwt_secret.as_bytes()),
            &access_validation(&bad),
        );
        assert!(err.is_err());
    }

    #[test]
    fn bearer_prefix_required_for_authorization_header() {
        let value = "Bearer abc.def.ghi";
        assert_eq!(value.strip_prefix("Bearer ").unwrap(), "abc.def.ghi");
        assert!("Token abc".strip_prefix("Bearer ").is_none());
    }
}
