use chrono::Utc;
use redis::AsyncCommands;
use uuid::Uuid;

use crate::db::AppState;
use crate::error::ApiError;

fn online_key(user_id: Uuid) -> String {
    format!("presence:online:{user_id}")
}

fn last_seen_key(user_id: Uuid) -> String {
    format!("presence:last_seen:{user_id}")
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct PresenceInfo {
    pub user_id: String,
    pub online: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_seen: Option<String>,
}

impl PresenceInfo {
    fn offline(user_id: Uuid, last_seen: Option<String>) -> Self {
        Self {
            user_id: user_id.to_string(),
            online: false,
            last_seen,
        }
    }

    fn online_now(user_id: Uuid, last_seen: String) -> Self {
        Self {
            user_id: user_id.to_string(),
            online: true,
            last_seen: Some(last_seen),
        }
    }
}

fn now_rfc3339() -> String {
    Utc::now().to_rfc3339()
}

fn parse_last_seen(raw: Option<String>) -> Option<String> {
    raw.and_then(|s| if s.is_empty() { None } else { Some(s) })
}

pub async fn heartbeat(state: &AppState, user_id: Uuid) -> Result<PresenceInfo, ApiError> {
    let ttl = state.config.presence_timeout_secs.max(5) as i64;
    let ts = now_rfc3339();
    let mut redis = state.redis.clone();

    redis
        .set_ex::<_, _, ()>(online_key(user_id), "1", ttl as u64)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    redis
        .set::<_, _, ()>(last_seen_key(user_id), &ts)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(PresenceInfo::online_now(user_id, ts))
}

pub async fn set_offline(state: &AppState, user_id: Uuid) -> Result<PresenceInfo, ApiError> {
    let ts = now_rfc3339();
    let mut redis = state.redis.clone();

    let _: () = redis
        .del(online_key(user_id))
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    redis
        .set::<_, _, ()>(last_seen_key(user_id), &ts)
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;

    Ok(PresenceInfo::offline(user_id, Some(ts)))
}

pub async fn get_presence(state: &AppState, user_id: Uuid) -> Result<PresenceInfo, ApiError> {
    let mut redis = state.redis.clone();

    let online: bool = redis
        .exists(online_key(user_id))
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    let last_seen: Option<String> = redis
        .get(last_seen_key(user_id))
        .await
        .map_err(|e| ApiError::Internal(e.to_string()))?;
    let last_seen = parse_last_seen(last_seen);

    if online {
        Ok(PresenceInfo {
            user_id: user_id.to_string(),
            online: true,
            last_seen,
        })
    } else {
        Ok(PresenceInfo::offline(user_id, last_seen))
    }
}

pub async fn is_online(state: &AppState, user_id: Uuid) -> Result<bool, ApiError> {
    Ok(get_presence(state, user_id).await?.online)
}

pub async fn get_many(state: &AppState, user_ids: &[Uuid]) -> Result<Vec<PresenceInfo>, ApiError> {
    let mut out = Vec::with_capacity(user_ids.len());
    for id in user_ids {
        out.push(get_presence(state, *id).await?);
    }
    Ok(out)
}
